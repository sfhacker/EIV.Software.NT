﻿namespace EIV.UI.MainApp
{
    using System.Windows;
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private Usuario currentUser = null;

        public App()
        {
           this.InitializeComponent();
        }

        public Usuario CurrentUser
        {
            get
            {
                return this.currentUser;
            }
            set
            {
                this.currentUser = value;
            }
        }
    }
}