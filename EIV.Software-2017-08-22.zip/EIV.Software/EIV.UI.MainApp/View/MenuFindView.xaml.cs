﻿
namespace EIV.UI.MainApp.View
{
    using System.Collections.ObjectModel;
    using System.Linq;
    using System.Windows;
    using System.Windows.Input;

    using Telerik.Windows.Controls;
    /// <summary>
    /// Interaction logic for MenuFindView.xaml
    /// </summary>
    public partial class MenuFindView : RadWindow
    {
        private ObservableCollection<MenuItem> menuList = null;

        public MenuFindView()
        {
            InitializeComponent();

            // It should take the Theme from its parent!
            this.Style = new Style(GetType(), this.FindResource(typeof(Telerik.Windows.Controls.RadWindow)) as Style);

            MenuService.MenuService menuService = new MainApp.MenuService.MenuService();
            menuService.LoadFullMenu();
            // menuService.GenerateUserMenu();

            System.Collections.Generic.IList<MenuItem> testList = new System.Collections.Generic.List<MenuItem>();

            // 418 in total (report menu items are missing)
            this.FindLeaves(menuService.MainMenu, testList);

            System.Collections.Generic.IList<MenuItem> orderedList = testList.OrderBy(q => q.Text).ToList();

            menuList = new ObservableCollection<MenuItem>(orderedList);    //  menuService.MainMenu.SubItems);

            this.searchBox.MouseDoubleClick += SearchBox_MouseDoubleClick;
            this.searchBox.SelectionChanged += SearchBox_SelectionChanged;

            this.searchBox.SearchProperties = "Text";

            this.searchBox.DisplayMemberPath = "Header";

            this.searchBox.ItemsSource = menuList;
        }

        private void SearchBox_SelectionChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            //throw new System.NotImplementedException();
            // var testOracle = "adadas";
        }

        private void SearchBox_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            MenuItem thisMenu = this.searchBox.SelectedItem as MenuItem;
            if (thisMenu != null)
            {
                MessageBox.Show(string.Format("{0}: {1}", thisMenu.Text, thisMenu.Name), "Busca Menu", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void FindLeaves(MenuItem p, System.Collections.Generic.ICollection<MenuItem> leaves)
        {
            if (p.SubItems.Count == 0) return;

            var toVisit = new System.Collections.Generic.Stack<MenuItem>(p.SubItems);

            while (toVisit.Count > 0)
            {
                var current = toVisit.Pop();

                foreach (var child in current.SubItems)
                {
                    if (child.SubItems.Count == 0)
                        leaves.Add(child);
                    else
                        toVisit.Push(child);
                }
            }
        }
    }
}