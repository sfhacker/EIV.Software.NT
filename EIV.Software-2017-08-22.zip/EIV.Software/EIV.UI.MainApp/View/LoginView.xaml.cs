﻿
namespace EIV.UI.MainApp.View
{
    using System.Windows;
    using Telerik.Windows.Controls;
    using ViewModel;

    /// <summary>
    /// Lógica de interacción para LoginView.xaml
    /// </summary>
    public partial class LoginView : RadWindow
    {
        private UsuarioService userService = null;

        private Usuario currentUser = null;

        public LoginView()
        {
            InitializeComponent();

            // It should take the Theme from its parent!
            this.Style = new Style(GetType(), this.FindResource(typeof(Telerik.Windows.Controls.RadWindow)) as Style);

            this.txtUserName.Text = "";
            this.txtUserName.Password = "";
            this.txtUserName.MaxLength = 32;
            this.txtUserName.ShowPasswordButtonVisibility = ShowPasswordButtonVisibilityMode.Auto;
            this.txtUserName.WatermarkBehavior = WatermarkBehavior.HideOnTextEntered;

            this.txtPassword.Text = "";
            this.txtPassword.Password = "";
            this.txtPassword.MaxLength = 32; 
            this.txtPassword.ShowPasswordButtonVisibility = ShowPasswordButtonVisibilityMode.Never;
            this.txtPassword.WatermarkBehavior = WatermarkBehavior.HideOnTextEntered;

            this.cboSeguridad.SelectedIndex = 0;
            //this.cboSucursal.SelectedIndex = 0;
            this.cboSucursal.Items.Clear();

            this.currentUser = null;

            this.userService = new UsuarioService();
        }

        private void btnLogin_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            string strUserName = this.txtUserName.Password;
            string strPassword = this.txtPassword.Password;
            string strSeguridad = null;

            // testing ....
            if (this.currentUser != null)
            {
                if (this.currentUser.IsAuthenticated)
                {
                    if (this.cboSucursal.SelectedIndex != -1)
                    {
                        this.currentUser.SelectedBranch = this.cboSucursal.SelectedIndex;

                        //MessageBox.Show(this.cboSucursal.SelectedItem as string, "Sucursal");

                        this.Close();

                        return;
                    }
                }
            }
            if (string.IsNullOrEmpty(strUserName))
            {
                RadWindow.Alert("Nombre de Usuario invalido");

                return;
            }
            if (string.IsNullOrEmpty(strPassword))
            {
                RadWindow.Alert("Password invalido");

                return;
            }

            if (this.cboSeguridad.SelectedItem != null)
            {
                RadComboBoxItem cboItem = this.cboSeguridad.SelectedItem as RadComboBoxItem;
                strSeguridad = cboItem.Content as string;
            }

            string txtMsg = string.Format("{0};{1};{2}", strUserName, strPassword, strSeguridad);

            MessageBox.Show(txtMsg);

            this.currentUser = this.userService.Authenticate(strUserName, strPassword);

            if (this.currentUser != null)
            {
                // RadWindow.Alert("Login Ok!");

                this.SetSucursal(currentUser);

                LoginViewModel loginModel = this.DataContext as LoginViewModel;
                if (loginModel != null)
                {
                    loginModel.CurrentUser = currentUser;
                }

                this.btnLogin.IsEnabled = false;

                if (currentUser.Sucursales.Count == 1)
                {
                    this.Close();

                    return;
                }

                this.btnLogin.Content = "Continuar ...";
                //this.btnLogin.Click += new RoutedEventHandler(btnLoginContinuar_Click);       // += btnLoginContinuar_Click;
                this.btnLogin.IsEnabled = true;

                return;
            }

            RadWindow.Alert("You shall not pass");
        }

        //private void btnLoginContinuar_Click(object sender, System.Windows.RoutedEventArgs e)
        //{
        //    e.Handled = true;

        //    if (this.cboSucursal.SelectedIndex == -1)
        //    {
        //        return;
        //    }

        //    MessageBox.Show(this.cboSucursal.SelectedItem as string);

        //    this.Close();

        //    return;
        //}

        private void btnCancel_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            this.txtUserName.Password = "";
            this.txtPassword.Password = "";
            this.cboSucursal.Items.Clear();
        }

        private void cboSeguridad_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            int cboIndex = this.cboSeguridad.SelectedIndex;

            if (cboIndex > 0)
            {
                this.txtUserName.Password = "";
                this.txtUserName.IsEnabled = false;

                this.txtPassword.Password = "";
                this.txtPassword.IsEnabled = false;

                //this.stackSucursal.Visibility = Visibility.Visible;
                this.lblSucursal.Visibility = Visibility.Visible;
                this.cboSucursal.Visibility = Visibility.Visible;

                return;
            }

            this.txtUserName.IsEnabled = true;
            this.txtPassword.IsEnabled = true;

            //this.stackSucursal.Visibility = Visibility.Collapsed;

            //this.lblSucursal.Visibility = Visibility.Hidden;
            //this.cboSucursal.Visibility = Visibility.Hidden;
        }

        private void cboSucursal_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
        }

        private void SetSucursal(Usuario user)
        {
            if (user == null)
            {
                return;
            }

            if (user.Sucursales == null)
            {
                return;
            }
            if (user.Sucursales.Count == 0)
            {
                return;
            }
            this.cboSucursal.Items.Clear();
            foreach (string sucursal in user.Sucursales)
            {
                this.cboSucursal.Items.Add(sucursal);
            }

            this.cboSucursal.SelectedIndex = 0;
            if (this.cboSucursal.Items.Count > 1)
            {
                this.cboSucursal.IsEnabled = true;
                //this.cboSucursal.IsEditable = true;
            }
        }
    }
}