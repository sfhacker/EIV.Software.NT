﻿
namespace EIV.Plugin
{
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using EIV.Plugin.Helpers;
    public abstract class ABMViewModelBase : ViewModelBase
    {
        public abstract string Title { get; set; }
        public abstract string Icon { get; set; }

        public abstract DataFormViewModel DataFormModel { get; set; }

        // oData Service Context
        // Optional ?
        public virtual object DataServiceContext { get; set; }

        public virtual void SetLexicoContext(object lexicoContext) { }
        // Testing ...
        public virtual void ApplyLexico() { }

        // Telerik controls
        // GridViewColumn
        // GridViewBoundColumnBase
        public abstract IList<object> GridColumns { get; }

        // Rows
        public abstract ObservableCollection<object> GridContent { get; }


        // ABM Operations
        public abstract RelayCommand CancelCommand { get; set; }
        public abstract RelayCommand SaveCommand { get; set; }
        public abstract RelayCommand InsertCommand { get; set; }
        public abstract RelayCommand UpdateCommand { get; set; }
        public abstract RelayCommand DeleteCommand { get; set; }
    }
}