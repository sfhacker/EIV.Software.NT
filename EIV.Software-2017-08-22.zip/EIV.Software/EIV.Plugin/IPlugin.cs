﻿
namespace EIV.Plugin
{
    public interface IPlugin
    {
        IPluginHost Host { get; set; }

        string Name { get; }
        string Description { get; }

        void Initialize();
        void Dispose();
    }
}