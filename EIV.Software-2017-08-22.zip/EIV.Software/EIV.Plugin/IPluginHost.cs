﻿
namespace EIV.Plugin
{
    public interface IPluginHost
    {
        void Feedback(IPlugin plugin);
    }
}