﻿
namespace EIV.Plugin
{
    public interface IPluginService
    {
    }
}