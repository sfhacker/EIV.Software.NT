﻿/// <summary>
/// 
/// </summary>
namespace EIV.Plugin
{
    public sealed class DataFormViewModel : ViewModelBase
    {
        public ABMViewModelBase ParentViewModel { get; }
        public string Title { get; set; }
        public object CurrentItem { get; set; }

        public int StatusCode { get; set; }
        public string StatusMessage { get; set; }

        public string ErrorMessage { get; set; }

        public DataFormViewModel(ABMViewModelBase parentViewModel)
        {
            this.ParentViewModel = parentViewModel;
        }

        public void Insert(object entity)
        {
            if (entity == null)
            {
                return;
            }
            if (this.ParentViewModel != null)
            {
                this.ParentViewModel.InsertCommand.Execute(entity);
            }
        }

        public void Update(object entity)
        {
            if (entity == null)
            {
                return;
            }
            if (this.ParentViewModel != null)
            {
                this.ParentViewModel.UpdateCommand.Execute(entity);
            }
        }

        public void Delete(object entity)
        {
            if (entity == null)
            {
                return;
            }
            if (this.ParentViewModel != null)
            {
                this.ParentViewModel.DeleteCommand.Execute(entity);
            }
        }

        public event System.EventHandler AutoGeneratingField;
    }
}