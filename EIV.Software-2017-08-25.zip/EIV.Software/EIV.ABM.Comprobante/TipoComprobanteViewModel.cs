﻿/// <summary>
/// PresentationFramework
/// Telerik.Windows.Controls
/// Telerik.Windows.Controls.GridView
/// </summary>
namespace EIV.ABM.Comprobante
{
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;

    using EIV.Plugin;
    using EIV.Plugin.Helpers;

    using Telerik.Windows.Controls;

    public sealed class TipoComprobanteViewModel : ABMViewModelBase, IPluginGUI
    {
        // From Menu Option
        private string myName = "mnufrmtipodecomprobante"; // "Tipo Comprobante Template";
        private string windowTitle = "Tipo de Comprobantes";
        private string dataFormTitle = "Tipo de Comprobantes Data Form";

        private IPluginHost myHost = null;

        private RelayCommand cancelCommand = null;
        private RelayCommand saveCommand = null;
        private RelayCommand addTipoComprobanteCommand = null;
        private RelayCommand updateTipoComprobanteCommand = null;
        private RelayCommand deleteTipoComprobanteCommand = null;

        private IList<object> gridColumns = null;
        private ObservableCollection<object> gridContent = null;

        private DataFormViewModel myDataFormModel = null;

        private object myLexicoContext = null;

        // oData Service Context
        private object myDataServiceContext = null;

        public TipoComprobanteViewModel()
        {
            this.cancelCommand = new RelayCommand(DoCancel);
            this.saveCommand = new RelayCommand(DoSave);
            this.addTipoComprobanteCommand = new RelayCommand(AddTipoComprobante);
            this.updateTipoComprobanteCommand = new RelayCommand(UpdateTipoComprobante);
            this.deleteTipoComprobanteCommand = new RelayCommand(DeleteTipoComprobante);

            // DataForm View Model
            this.myDataFormModel = new DataFormViewModel(this);

            this.myDataFormModel.Title = this.dataFormTitle;
            this.myDataFormModel.CurrentItem = null;

            this.gridColumns = this.GenerateColumns();

            // this line should be in the other constructor
            // it requires oData Service context
            // or it should be when the grid is loaded!!!!

            // TODO:
            //this.gridContent = this.LoadEntities();
        }

        public TipoComprobanteViewModel(object serviceContext) : this()
        {
            this.myDataServiceContext = serviceContext;

            // This should be done when the grid is loading, not at this time!
            this.gridContent = this.LoadDataFromService();
        }

        #region ABMViewModelBase Class Members
        public override RelayCommand InsertCommand
        {
            get
            {
                return this.addTipoComprobanteCommand;
            }

            set
            {
            }
        }

        public override RelayCommand CancelCommand
        {
            get
            {
                return this.cancelCommand;
            }

            set
            {
            }
        }

        public override DataFormViewModel DataFormModel
        {
            get
            {
                return this.myDataFormModel;
            }

            set
            {
            }
        }

        public override RelayCommand DeleteCommand
        {
            get
            {
                return this.deleteTipoComprobanteCommand;
            }

            set
            {
            }
        }

        public string Description
        {
            get
            {
                throw new NotImplementedException();
            }
        }

        public override IList<object> GridColumns
        {
            get
            {
                return this.gridColumns;
            }
        }

        public override ObservableCollection<object> GridContent
        {
            get
            {
                return this.gridContent;
            }
        }

        public IPluginHost Host
        {
            get
            {
                return this.myHost;
            }

            set
            {
                this.myHost = value;
            }
        }

        public override string Icon
        {
            get
            {
                throw new NotImplementedException();
            }

            set
            {
                throw new NotImplementedException();
            }
        }

        public System.Windows.FrameworkElement MainInterface
        {
            get
            {
                return null;
            }
        }

        public string Name
        {
            get
            {
                return this.myName;
            }
        }

        public override RelayCommand SaveCommand
        {
            get
            {
                return this.saveCommand;
            }

            set
            {
            }
        }

        public override string Title
        {
            get
            {
                return this.windowTitle;
            }

            set
            {
                
            }
        }

        public ABMViewModelBase ViewModel
        {
            get
            {
                return this;
            }
        }

        public override RelayCommand UpdateCommand
        {
            get
            {
                return this.updateTipoComprobanteCommand;
            }

            set
            {
            }
        }

        public void Dispose()
        {
        }

        public void Initialize()
        {
        }

        public void SetDataServiceContext(object serviceContext)
        {
        }
        #endregion

        #region Commands
        private void DoCancel(object param)
        {
        }

        private void DoSave(object param)
        {
            // we should save here
            if (param != null)
            {
                if (this.gridContent != null)
                {
                    this.gridContent.Add(param);
                }
            }
        }

        private void AddTipoComprobante(object parameter)
        {
            if (parameter != null)
            {
                if (this.gridContent != null)
                {
                    // it displays this item onto the grid
                    this.gridContent.Add(parameter);
                }
            }
        }

        private void UpdateTipoComprobante(object parameter)
        {
        }

        private void DeleteTipoComprobante(object parameter)
        {
        }
        #endregion

        #region Lexico / Language
        private void ColumnsTranslate()
        {
            if (this.gridColumns == null)
            {
                return;
            }
            EIV.Globalization.Localization myLocal = null;

            if (this.myLexicoContext == null)
            {
                return;
            }

            myLocal = this.myLexicoContext as EIV.Globalization.Localization;
            foreach (GridViewDataColumn col in this.gridColumns)
            {
                object colText = myLocal.GetLexicoEntryValue(col.UniqueName);
                if (colText != null)
                {
                    col.Header = colText.ToString();
                }
            }
        }
        #endregion

        #region Columns & Data
        private ObservableCollection<object> GenerateColumns()
        {
            ObservableCollection<object> rst = new ObservableCollection<object>();

            rst.Add(new GridViewDataColumn() { Header = "Id", UniqueName = "tipo_comp_id", DataMemberBinding = new System.Windows.Data.Binding("Id") });
            rst.Add(new GridViewDataColumn() { Header = "Tipo", UniqueName = "tipo_comp_tipo", DataMemberBinding = new System.Windows.Data.Binding("Tipo") });
            rst.Add(new GridViewDataColumn() { Header = "Descripcion", UniqueName = "tipo_comp_desc", DataMemberBinding = new System.Windows.Data.Binding("Descripcion") });

            // OK
            rst.Add(new GridViewComboBoxColumn() { Header = "Comp. Assoc.", UniqueName = "tipo_comp_assoc", DataMemberBinding = new System.Windows.Data.Binding("ComprobantesAsociados") { Mode = System.Windows.Data.BindingMode.TwoWay }, ItemsSource = this.GetAllCompAssoc(), SelectedValueMemberPath = "Id", DisplayMemberPath = "Nombre" });

            return rst;
        }

        private ObservableCollection<object> LoadDataFromService()
        {
            ObservableCollection<object> rst = null;

            if (this.myDataServiceContext == null)
            {
                return null;
            }

            EIV.UI.ServiceContext.Service.UserControlService serviceContext = this.myDataServiceContext as EIV.UI.ServiceContext.Service.UserControlService;

            return serviceContext.LoadAllTipoComprobantes();
        }

        private ObservableCollection<object> GetAllCompAssoc()
        {
            // http://192.168.1.174:8080/eivfinanciero/odata/eivfinanciero.svc/TipoComprobantes?$expand=ComprobantesAsociados

            return null;
        }
        #endregion
    }
}