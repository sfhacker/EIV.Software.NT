﻿/// <summary>
/// if we inherit from 'IPluginGUI', we get an error!
/// PresentationFramework
/// </summary>
namespace EIV.ABM.Geografica
{
    using EIV.Plugin;
    using EIV.Plugin.Helpers;

    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using Telerik.Windows.Controls;

    public sealed class PaisesViewModel : ABMViewModelBase, IPluginGUI
    {
        // Entity Set Name
        private const string ENTITY_SET_NAME = "Paises";

        private string myName = "mnufrmpais";   // "Paises Template";
        private string windowTitle = "Paises";
        private string dataFormTitle = "Paises Data Form";

        private IPluginHost myHost = null;

        private RelayCommand cancelCommand = null;
        private RelayCommand saveCommand = null;
        private RelayCommand addPaisCommand = null;
        private RelayCommand updatePaisCommand = null;
        private RelayCommand deletePaisCommand = null;

        private IList<object> gridColumns = null;
        private ObservableCollection<object> gridContent = null;

        private DataFormViewModel myDataFormModel = null;

        private object myLexicoContext = null;

        // oData Service Context
        private object myDataServiceContext = null;

        public PaisesViewModel()
        {
            this.cancelCommand = new RelayCommand(DoCancel);
            this.saveCommand = new RelayCommand(DoSave);
            this.addPaisCommand = new RelayCommand(AddPais);
            this.updatePaisCommand = new RelayCommand(UpdatePais);
            this.deletePaisCommand = new RelayCommand(DeletePais);

            // DataForm View Model
            this.myDataFormModel = new DataFormViewModel(this);

            this.myDataFormModel.Title = this.dataFormTitle;
            this.myDataFormModel.CurrentItem = null;

            this.gridColumns = this.GenerateColumns();
        }

        public PaisesViewModel(object serviceContext) : this()
        {
            this.myDataServiceContext = serviceContext;

            // This should be done when the grid is loading, not at this time!
            this.gridContent = this.LoadDataFromService();
        }

        #region ABMViewModelBase Class Members
        public override RelayCommand InsertCommand
        {
            get
            {
                return this.addPaisCommand;
            }

            set
            {
            }
        }

        public override RelayCommand CancelCommand
        {
            get
            {
                return this.cancelCommand;
            }

            set
            {
            }
        }

        public override DataFormViewModel DataFormModel
        {
            get
            {
                return this.myDataFormModel;
            }

            set
            {
            }
        }

        public override RelayCommand DeleteCommand
        {
            get
            {
                return this.deletePaisCommand;
            }

            set
            {
            }
        }
        #endregion
        #region IPluginGUI Interface members
        public string Description
        {
            get
            {
                throw new NotImplementedException();
            }
        }

        public override IList<object> GridColumns
        {
            get
            {
                return this.gridColumns;
            }
        }

        public override ObservableCollection<object> GridContent
        {
            get
            {
                return this.gridContent;
            }
        }

        public IPluginHost Host
        {
            get
            {
                return this.myHost;
            }

            set
            {
                this.myHost = value;
            }
        }

        public override string Icon
        {
            get
            {
                return null;
            }

            set
            {
                throw new NotImplementedException();
            }
        }

        public System.Windows.FrameworkElement MainInterface
        {
            get
            {
                return null;
            }
        }

        public string Name
        {
            get
            {
                return this.myName;
            }
        }

        public override RelayCommand SaveCommand
        {
            get
            {
                return this.saveCommand;
            }

            set
            {
            }
        }

        public override string Title
        {
            get
            {
                return this.windowTitle;
            }

            set
            {
            }
        }

        public ABMViewModelBase ViewModel
        {
            get
            {
                return this;
            }
        }

        public override RelayCommand UpdateCommand
        {
            get
            {
                return this.updatePaisCommand;
            }

            set
            {
            }
        }

        public void Dispose()
        {
        }

        public void Initialize()
        {
            // Nothing here
        }

        public void SetDataServiceContext(object serviceContext)
        {
            this.myDataServiceContext = serviceContext;
        }
        #endregion

        #region Commands
        private void DoCancel(object param)
        {
        }

        private void DoSave(object param)
        {
            // we should save here
            if (param != null)
            {
                if (this.gridContent != null)
                {
                    this.gridContent.Add(param);
                }
            }
        }

        private void AddPais(object parameter)
        {
            if (parameter != null)
            {
                if (this.gridContent != null)
                {
                    // it displays this item onto the grid
                    this.gridContent.Add(parameter);

                    // Should I persist this entity onto the DB at this time?
                    if (this.myDataServiceContext != null)
                    {
                        EIV.UI.ServiceContext.Service.UserControlService serviceContext = this.myDataServiceContext as EIV.UI.ServiceContext.Service.UserControlService;
                        var rst = serviceContext.Insert(ENTITY_SET_NAME, parameter);
                        if (rst != null)
                        {
                            this.myDataFormModel.StatusCode = rst.StatusCode;
                            this.myDataFormModel.StatusMessage = rst.Message;
                            this.myDataFormModel.ErrorMessage = rst.Error;
                        }

                        // TODO: El method de arribo NO (?) deberia persistir los datos, pero lo
                        // deberia decidir el usuario?
                        //var rst = serviceContext.SaveChanges();
                    }
                }
            }
        }

        private void UpdatePais(object parameter)
        {
            if (parameter == null)
            {
                return;
            }
            // Should I persist this entity onto the DB at this time?
            if (this.myDataServiceContext != null)
            {
                EIV.UI.ServiceContext.Service.UserControlService serviceContext = this.myDataServiceContext as EIV.UI.ServiceContext.Service.UserControlService;
                var rst = serviceContext.Update(parameter);
                if (rst != null)
                {
                    this.myDataFormModel.StatusCode = rst.StatusCode;
                    this.myDataFormModel.StatusMessage = rst.Message;
                    this.myDataFormModel.ErrorMessage = rst.Error;
                }

                // TODO: El method de arribo NO (?) deberia persistir los datos, pero lo
                // deberia decidir el usuario?
                //var rst = serviceContext.SaveChanges();
            }
        }

        private void DeletePais(object parameter)
        {
            if (parameter == null)
            {
                return;
            }
            // Should I persist this entity onto the DB at this time?
            if (this.myDataServiceContext != null)
            {
                EIV.UI.ServiceContext.Service.UserControlService serviceContext = this.myDataServiceContext as EIV.UI.ServiceContext.Service.UserControlService;
                var rst = serviceContext.Delete(parameter);
                if (rst != null)
                {
                    this.myDataFormModel.StatusCode = rst.StatusCode;
                    this.myDataFormModel.StatusMessage = rst.Message;
                    this.myDataFormModel.ErrorMessage = rst.Error;
                }

                // TODO: El method de arribo NO (?) deberia persistir los datos, pero lo
                // deberia decidir el usuario?
                //var rst = serviceContext.SaveChanges();
            }
        }
        #endregion

        #region Columns & Data
        private ObservableCollection<object> GenerateColumns()
        {
            ObservableCollection<object> rst = new ObservableCollection<object>();

            rst.Add(new GridViewDataColumn() { Header = "Id", UniqueName = "pais_id", DataMemberBinding = new System.Windows.Data.Binding("Id") });
            rst.Add(new GridViewDataColumn() { Header = "Descripcion", UniqueName = "pais_desc", DataMemberBinding = new System.Windows.Data.Binding("Descripcion") });
            rst.Add(new GridViewDataColumn() { Header = "Nacionalidad", UniqueName = "pais_nacion", DataMemberBinding = new System.Windows.Data.Binding("Nacionalidad") });
            rst.Add(new GridViewDataColumn() { Header = "Prefijo", UniqueName = "pais_prefijo", DataMemberBinding = new System.Windows.Data.Binding("Prefijo") });

            return rst;
        }

        private ObservableCollection<object> LoadDataFromService()
        {
            ObservableCollection<object> rst = null;

            if (this.myDataServiceContext == null)
            {
                return null;
            }

            EIV.UI.ServiceContext.Service.UserControlService serviceContext = this.myDataServiceContext as EIV.UI.ServiceContext.Service.UserControlService;

            return serviceContext.LoadAllPaises();
        }

        #endregion
    }
}