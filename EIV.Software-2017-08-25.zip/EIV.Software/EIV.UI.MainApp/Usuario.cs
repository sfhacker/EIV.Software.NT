﻿

namespace EIV.UI.MainApp
{
    using System.Collections.Generic;
    public sealed class Usuario
    {
        public Usuario()
        {
            this.Sucursales = null;
            this.UserMenu = null;
            this.IsAuthenticated = false;
            this.SelectedBranch = -1;
        }

        public bool IsAuthenticated { get; internal set; }
        public string UserName { get; set; }

        public int SelectedBranch { get; internal set; }
        public IList<string> Sucursales { get; set; }

        public MenuItem UserMenu { get; set; }
    }
}