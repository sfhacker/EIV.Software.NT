﻿
namespace EIV.UI.MainApp
{
    using Microsoft.Win32;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Windows;
    using System.Windows.Data;
    using Telerik.Windows;
    using Telerik.Windows.Controls;
    using Telerik.Windows.Controls.GridView;

    /// <summary>
    /// Interaction logic for TestRadWindow.xaml
    /// </summary>
    public partial class TestRadWindow : Telerik.Windows.Controls.RadWindow
    {
        private Plugin.ABMViewModelBase myViewModel = null;

        private EIV.TelerikThemes.TelerikTheme myTheme = null;
        private EIV.Globalization.Localization myLocalization = null;

        public TestRadWindow()
        {
            //StyleManager.SetTheme(this, new Office_BlueTheme());
            //Theme alas = StyleManager.GetTheme(this);

            InitializeComponent();

            // alas = StyleManager.GetTheme(this);

            // It should take the Theme from its parent!
            this.Style = new Style(GetType(), this.FindResource(typeof(Telerik.Windows.Controls.RadWindow)) as Style);

            //alas = StyleManager.GetTheme(this);
        }

        #region Grid Events
        private void gridView_DataLoading(object sender, Telerik.Windows.Controls.GridView.GridViewDataLoadingEventArgs e)
        {
            //this.gridStatusInfo = "Cargando datos ...";

            GridViewDataControl dataControl = (GridViewDataControl)sender;
            if (dataControl != null)
            {
                dataControl.IsBusy = true;
            }
        }

        private void gridView_Loaded(object sender, System.Windows.RoutedEventArgs e)
        {
            //if (this.genericTemplate == null)
            //{
            //    return;
            //}
            GridViewDataControl dataControl = (GridViewDataControl)sender;
            if (dataControl != null)
            {
                this.myViewModel = this.DataContext as Plugin.ABMViewModelBase;
                //dataControl.ItemsSource = genericLocalidades.
                // how often does it come here?
                //dataControl.Columns.Clear();
                dataControl.Columns.Add(new MyButtonColumn(new RoutedEventHandler(this.ButtonTest_Click))
                {
                    Header = "Editar"
                });

                // TODO: 2017-07-31 + 2017-08-02
                if (this.myViewModel != null)
                {
                    if (this.myViewModel.GridColumns != null)
                    {
                        // TODO: Need to localize all the columns here
                        IEnumerable<GridViewColumn> testOne = this.myViewModel.GridColumns.Cast<GridViewColumn>();

                        dataControl.Columns.AddRange(testOne);
                    }

                    //dataControl.Columns = this

                    dataControl.ItemsSource = this.myViewModel.GridContent;
                }


                //// Stack Overflow!
                //dataControl.ItemsSource = this.myViewModel.GridContent;  // this.gridContent;

                this.dataPager.SetBinding(RadDataPager.SourceProperty, new Binding("Items") { Source = this.gridView });

                // TODO:
                /*
                // CreateDataPager(dataControl);
                this.BindDataPager(this.gridPager, dataControl);

                ObservableCollection<Pais> items = this.LoadPaises();

                SetGridSource(dataControl, items);
                */
            }
        }

        private void gridView_Deleting(object sender, Telerik.Windows.Controls.GridViewDeletingEventArgs e)
        {
            if (e.Items != null)
            {
                //this.genericLocalidades.Delete(e.Items);

                // TODO:
                /* User can delete more than one row at the same time */
                /*List<Pais> paises = e.Items.Cast<Pais>().ToList();

                if (paises != null)
                {
                    if (paises.Count > 0)
                    {
                        /* this.customViewModel.RemoveEntities<Pais>(paises); */
                /*  }
              }*/
            }
        }

        private void gridView_RowEditEnded(object sender, Telerik.Windows.Controls.GridViewRowEditEndedEventArgs e)
        {
            // TODO:
            //Pais newPais = null;

            if (e.EditAction == GridViewEditAction.Cancel)
            {
                e.UserDefinedErrors.Clear();

                return;
            }

            if (e.EditOperationType == GridViewEditOperationType.Insert)
            {
                GridViewRow row = e.Row;
                if (e.Row is GridViewNewRow)
                {
                    object cellValue = e.OldValues;

                    //this.genericLocalidades.Insert(e.NewData);
                }

                return;
            }

            if (e.EditOperationType == GridViewEditOperationType.Edit)
            {
                GridViewRow row = e.Row;
                if (e.Source is GridViewComboBoxColumn)
                {
                    var one = "alas";
                }
                IDictionary<string, object> cellOldValues = e.OldValues;
                object cellNewValues = e.NewData;

                // Issue when changing an item in any Combo Box
                //this.genericLocalidades.Update(e.NewData);
            }
        }

        private void gridView_DataLoaded(object sender, System.EventArgs e)
        {
            //this.gridStatusInfo = "Carga de datos completa!";

            GridViewDataControl dataControl = (GridViewDataControl)sender;
            if (dataControl != null)
            {
                dataControl.IsBusy = false;
            }
        }

        private void gridView_CellValidating(object sender, GridViewCellValidatingEventArgs e)
        {
            if (this.gridView.CurrentCell != null)
            {
                GridViewCell cellIndex = e.Cell;
                GridViewRowItem rowItem = e.Row;
                //object initialCellValue = e.Row.Cells[cellIndex].Value;
                //if (!initialValues.ContainsKey(cellIndex))
                //{
                //    initialValues.Add(cellIndex, initialCellValue);
                //}

                //this.gridView.rebi
            }
        }

        private void gridView_CellEditEnded(object sender, GridViewCellEditEndedEventArgs e)
        {
        }

        private void gridView_CurrentCellChanged(object sender, GridViewCurrentCellChangedEventArgs e)
        {

        }

        private void gridView_CellValidated(object sender, GridViewCellValidatedEventArgs e)
        {
        }

        private void ButtonTest_Click(object sender, RoutedEventArgs e)
        {
            //RadWindow.Alert("here new 2017");

            var senderElement = e.OriginalSource as FrameworkElement;
            var row = senderElement.ParentOfType<GridViewRow>();

            if (row != null)
            {
                row.IsSelected = true;
                //this.gridView.CurrentItem = row.DataContext;

                //var alas = new MyDataFormViewModel();
                //alas.Title = "Localidades Data Form";
                //alas.CurrentItem = row.DataContext;
                if (this.myViewModel.DataFormModel == null)
                {
                    return;
                }
                this.myViewModel.DataFormModel.CurrentItem = row.DataContext;

                RadWindow dataFormPopUp = new TestDataForm();
                dataFormPopUp.Owner = this;
                dataFormPopUp.Height = 300;
                dataFormPopUp.Width = 400;
                dataFormPopUp.WindowStartupLocation = WindowStartupLocation.CenterOwner;
                dataFormPopUp.DataContext = this.myViewModel.DataFormModel;            // alas;
                dataFormPopUp.ShowDialog();
            }
        }
        #endregion

        private void RadWindow_Loaded(object sender, RoutedEventArgs e)
        {
            this.myViewModel = this.DataContext as Plugin.ABMViewModelBase;

            if (this.myViewModel != null)
            {
                this.myViewModel.ApplyLexico();

                var radWindow = sender as RadWindow;
                radWindow.Header = this.myViewModel.Title;
            }

            // var here now
            Theme alas = StyleManager.GetTheme(this);
            if (alas == null)
            {
                //this.ApplyTheme(this.myTheme);
                //StyleManager.SetTheme(this, new Office_BlueTheme());

                alas = StyleManager.GetTheme(this);
            }
        }

        private void radContextMenu_ItemClick(object sender, RadRoutedEventArgs e)
        {
            RadMenuItem item = e.OriginalSource as RadMenuItem;
            //implement the logic regarding the instance here.
            if (item != null)
            {
                string extension = "htm";     // htm
                SaveFileDialog dialog = new SaveFileDialog()
                {
                    DefaultExt = extension,
                    Filter = String.Format("{1} files (*.{0})|*.{0}|All files(*.*)|*.*", extension, "HTML"),   // HTML
                    FilterIndex = 1
                };

                if (dialog.ShowDialog() == true)
                {
                    using (Stream stream = dialog.OpenFile())
                    {
                        this.gridView.Export(stream,
                            new GridViewExportOptions()
                            {
                                Format = ExportFormat.Html,    // Html
                                ShowColumnHeaders = true,
                                ShowColumnFooters = true,
                                ShowGroupFooters = false
                            });
                    }
                }
            }
        }
    }

    public sealed class MyButtonColumn : Telerik.Windows.Controls.GridViewColumn
    {
        private readonly EventHandler btnClickEvent = null;
        private readonly RoutedEventHandler btnRoutedClickEvent = null;

        public MyButtonColumn()
        {

        }

        //public MyButtonColumn(EventHandler clickEvent)
        //{
        //    this.btnClickEvent = clickEvent;
        //}

        public MyButtonColumn(RoutedEventHandler routedClickEvent)
        {
            this.btnRoutedClickEvent = routedClickEvent;
        }

        public override FrameworkElement CreateCellElement(GridViewCell cell, object dataItem)
        {
            RadButton button = cell.Content as RadButton;
            if (button == null)
            {
                button = new RadButton();
                button.Content = "Editar";
                //button.Command = RadGridViewCommands.Search;
                if (this.btnRoutedClickEvent != null)
                {
                    button.Click += this.btnRoutedClickEvent;  // new RoutedEventHandler(btnClickEvent);             // Button_Click;
                }

            }

            button.CommandParameter = dataItem;

            return button;
        }

        //private void Button_Click(object sender, RoutedEventArgs e)
        //{
        //    RadWindow.Alert("here");

        //    var senderElement = e.OriginalSource as FrameworkElement;
        //    var row = senderElement.ParentOfType<GridViewRow>();

        //    if (row != null)
        //        row.IsSelected = true;
        //}
    }
}