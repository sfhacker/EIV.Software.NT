﻿
namespace EIV.UI.MainApp
{
    using System.Collections.ObjectModel;
    using System.ComponentModel;
    public sealed class MenuItem : INotifyPropertyChanged
    {
        private string name;

        // 'Header' prop in Telerik RadMenuItem
        private string text;

        private string toolTip;
        private string iconUrl;

        private bool isEnabled;
        private bool isHidden;
        private bool isSeparator;

        private int menuType;

        private ObservableCollection<MenuItem> subItems = null;

        private MenuItem parentMenu;

        private string className = string.Empty;
        private string classMethod = string.Empty;

        public event PropertyChangedEventHandler PropertyChanged;

        // The property 'SubItems' on type 'EIV.Demo.Model.MenuItem' returned a null value. The input stream contains collection items which cannot be added if the instance is null.\r\n",
        // OData requires a public and parameterless constructor!
        public MenuItem()
        {
            this.subItems = new ObservableCollection<MenuItem>();
        }

        // if there is no setter, then OData never shows this property on the browser
        public string Name { get { return this.name; } set { this.name = value; } }

        public string Text { get { return this.text; } set { this.text = value; } }
        //public string Header { get { return this.text; } set { this.text = value; } }

        public int MenuType { get { return this.menuType; } set { this.menuType = value; } }

        public string Header
        {
            get
            {
                string rst = null;
                if (this.parentMenu != null)
                {
                    rst = string.Format("{0} ({1})", this.text, this.parentMenu.text);
                } else
                {
                    rst = this.text;
                }

                return rst;
            }

        }
        /* Proxy class does not work if we use Uri object
        public Uri IconUrl */
        public string IconUrl
        {
            get { return this.iconUrl; }
            set { this.iconUrl = value; }
        }

        public bool IsEnabled
        {
            get
            {
                return this.isEnabled;
            }
            set
            {
                this.isEnabled = value;
            }
        }

        public bool IsHidden
        {
            get
            {
                return this.isHidden;
            }
            set
            {
                this.isHidden = value;
            }
        }

        public bool IsSeparator
        {
            get
            {
                return this.isSeparator;
            }
            set
            {
                this.isSeparator = value;
            }
        }

        public bool IsReport
        {
            get
            {
                if (this.MenuType == 200)
                {
                    if (this.Name.StartsWith("mnurpt") || this.Name.StartsWith("<reporte>"))
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        public string ToolTip
        {
            get
            {
                return this.toolTip;
            }
            set
            {
                this.toolTip = value;
            }
        }

        public string ClassName
        {
            get
            {
                return this.className;
            }
            set
            {
                this.className = value;
            }
        }

        public string ClassMethod
        {
            get
            {
                return this.classMethod;
            }
            set
            {
                this.classMethod = value;
            }
        }

        // The complex type 'EIV.Demo.Model.MenuItem' has a reference to itself through the property 'Parent'. A recursive loop of complex types is not allowed.
        // Nombre del parámetro: propertyInfo
        public MenuItem ParentMenu
        {
            get { return this.parentMenu; }
            set { this.parentMenu = value; }
        }

        public System.Windows.Input.ICommand Command
        {
            get;
            set;
        }

        public ObservableCollection<MenuItem> SubItems
        {
            get
            {
                return this.subItems;
            }
        }
        public void AddSubItem(MenuItem item)
        {
            this.subItems.Add(item);
        }
    }
}