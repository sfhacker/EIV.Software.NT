EIV SOFTWARE NT / 2017

[2017-07-31]

* Diseno sugerido

  - Programacion en capas (DAL, BAL & UI)
  
  - Lenguaje: .NET C# [v4.5.2]


>> EIV.Software
		Type: Solution


	1.- EIV.OData.Proxy

		Contiene clases proxy provenientes del servicio OData (eivfinanciero)
		[http://192.168.1.174:8080/eivfinanciero/odata/eivfinanciero.svc/]

		Type        : Class Library
		Dependencies: Microsoft.OData.Client (6.17+)
		Used by     : Aplicacion principal (?), UI service context
		Deployment  : Un solo assembly
		Tests       : N/A

		Motivation  : Reutilizacion

		Notes:
			Puede contener mas de una clase proxy y de diferentes lenguages (e.g. Java, .NET)
			No contiene codigo de 'usuario'
			Se actualiza facilmente (OneClick)

			Para abstraer toda la app del servicio oData, se podria utilizar una DLL que provea
			de servcios de queries, etc. Pero esta DLL podria 'engordar' mucho con el tiempo
			Por otro lado, tendria la ventaja de .....
	
	2.- EIV.Globalization
	
		Provee servicios de traduccion entre lexicos e idiomas.
		Los lexicos soportados son: Mutual, Cooperativa y Bancos. [Revisar]
		Los idiomas soportados son: Espanol, Ingles y Portugues.  [Revisar]

		Type        : Class Library
		Dependencies: PresentationCore, PresentationFramework, WindowsBase
		Used by     : Toda la aplicacion
		Deployment  : Un solo assembly
		Tests       : N/A

		Motivation  : Reutilizacion, encapsulamiento, mantenimiento

		Cuando se cambia un lexico, afecta a toda la aplicacion (el mismo para todos los usuarios)
		Cuando se cambia un idioma, afecta a toda la aplicacion, pero el idioma depende de cada usuario.
		La info sobre combinacion Idioma/Usuario se persiste en algun lado? O depende de la config. de la
		PC que dicho usuario utiliza regularmente?
		A modo de ejemplo, si nuestra App soporta tres idiomas, y se utiliza el idioma seleccionado en la PC
		del usuario, y un usuario cambia el idioma de su PC por uno que nuestra App no soporta,
		como deberia reaccionar nuestra App?

		Cada texto e imagen que se muestre x pantalla y/o imprima (reportes) debera ser localizado.
		Conviene tener toda esa info en un solo lugar o segregarlo en partes? Por ejemplo, cada ABM podria
		tener su propio traduccion x lexico e idioma. Pero esto no se podria utilizar para el resto de la 
		app!!!!


	3.- EIV.TelerikThemes

        Facilita la aplicacion de distintos estilos visuales a controles de usuario.
		Soporta 15 Telerik Themes aplicable a toda la aplicacion.

	    Type        : Class Library
		Dependencies: PresentationFramework
		Used by     : Toda la aplicacion
		Deployment  : Un solo assembly
		Tests       : N/A

		Motivation  : Reutilizacion

        Cuando se cambia un tema, afecta a toda la aplicacion, pero el tema depende de cada usuario.
		Donde/Como se almacena dicha info?


	4.- EIV.Helpers

		Funcionalidad generica disponible para toda la aplicacion
	
		Type        : Class Library
		Dependencies: Varios (e.g. JSon, XML, ...)
		Used by     : Toda la aplicacion
		Deployment  : Un solo assembly
		Tests       : N/A

		Motivation  : Reutilizacion


	5.- EIV.Plugin

		Projecto que permite la creacion de ABMs con la posibilidad de ser leidos en memoria
		dinamicamente.
		A su vez, se permite la agrupacion de ABMs por alguna categoria.
		En la solucion, se puede observar dos grupos de ABMs: Geografica (contiene 4 ABMs) y Comprobante (1 solo ABM).
		Estos dos grupos de ABMs se colocan en una carpeta especifica y son leidos x la aplicacion principal.
		Cada ABM debe tener un nombre univoco, el cual esta asociado a algun opcion del menu principal.
		Cuando un usuario hace click sobre dicho menu, se procede a renderizar el ABM correspondiente.

		Type        : Class Library
		Dependencies: PresentationCore, PresentationFramework
		Used by     : Aplicacion principal, cada ABM
		Deployment  : Un solo assembly
		Tests       : N/A


	6.- EIV.UI.ServiceContext

	    Type        : Class Library
		Dependencies: EIV.OData.Proxy, oData Client Library
		Used by     : Aplicacion principal, ABMs, .....
		Deployment  : Un solo assembly
		Tests       : N/A

		Motivacion  : Conexion al servicio OData, metodos varios requeridos x otros assemblies (e.g. ABMs)

					  Por otro lado, otra idea es que este assembly encapsule metodos requeridos x toda la aplicacion
					  en un solo lugar para facilitar su mantenimiento.

		Notas       : Esto puede ser overkill y eventualmente, convertirse en un DLL gigantesco!
		              Pero al mismo tiempo se pretende limitar al minimo las dependencias entre
					  proyectos. La idea seria que el ejecutable tenga este assembly unicamente
					  como dependencia (es factible? deseable? pretensioso?)

					  Conversando con Pablo y Guille se propuso crear una capa de servicio x cada modulo.
					  Por ejemplo, en ABM.Geografica crear una clase que encapsule todas las llamadas
					  al servicio. En ABM.Comprobante hacer lo mismo.

	7.- EIV.ABM.Geografica + EIV.ABM.Comprobante + otros ABMs

		Agrupa a todos los formularios ofrecido x la aplicacion.

		Type        : Class Library
		Dependencies: WPF + Telerik, Globalizacion, ABM base class, Service Context
		Used by     : Nadie ??? Leido en memoria de manera dinamica.
		Deployment  : Un solo assembly por grupo de ABMs
		Tests       : N/A

		Motivation  : Agregar, modificar formularios de manera independiente del resto de la aplicacion.
		              principalmente post deployment a produccion.

		Notas		: Un solo archivo por ABM
		              Pablo suguiere agregar un archivo de resource (lexico + idioma) x assembly


	8.- EIV.UI.MainApp
	
		Type        : WPF Application
		Dependencies: WPF + Telerik, Globalization, Telerik Themes, Service Context
		Used by     : N/A
		Deployment  : Ejecutable + dependencias
		Tests       : N/A
	
		Notas		: A modo de prueba de la diferente funcionalidad (Temas, Lexico, Idiomas, etc)
		              se agregaron varios entries al archivo App.config.

					  Cuando se levanta esta app (usuario no logeado hasta ahora), se procede a:

							> 'Conectarse' al servicio oData (deberia verificar que este up & running?)
							> Setear un Telerik Theme segun valor en App.config (o se utiliza uno predeterminado)
							> Setear un lexico (existe uno predeterminado? ningun usuario deberia poder cambiarlo?)
							> Setear un idioma segun valor en App.config o se utiliza el de la PC del usuario
							> Leer en memoria todos los ABMs segun valor en App.config (se instalan los DLLs en una
							                                                            carpeta especifica)
                              (Se leen todos los ABMs disponibles y luego se renderizan solo los que el usuario
							   logeado tiene permiso ?)

					 Cuando se logea un usuario, se procedera a:
							> Validar sus credenciales (se prevee soportar distinto tipos de credenciales?)
							> Fetch su menu y preferencias (e.g. Theme)
							> Agregar al menu principal existente, el menu de usuario

					Como conviene manejar el tema de authorizacion? Por ejemplo, cada ABM podria
					contener datos que faciliten (de una manera generica) el acceso a los mismos
					por diferentes usuarios. (Roles, grupos, etc)
					O esto aplica al menu de usuario, i.e. si un usuario tiene un menu de opciones particular,
					implica que siempre puede acceder al ABM o formulario o reporte o proceso o whatever? [Si]
					(o sea, esto lo resuelve el servicio oData?) Si los privilegios de un usuario cambian posterior a su logeo,
					entonces dicho usuario deberia deslogearse y volverse a logear ? [Si]

* Funcionamiento / Requerimientos / Dependencias

	- Revisar las dependencias entre proyectos

	- Revisar el diseno de la solucion (e.g. capas)

	- Como organizar el menu de opciones principal. Al presente, el menu principal (app. vigente) contiene
	  un numero (en algun caso) y letra (en otro caso) delante del nombre de la opcion del menu.
	  Se podria organizar alfabeticamente con algunas opciones fijas (por ejemplo)
	  El menu de opciones depende del usuario logeado, del grupo al que dicho usuario pertence,
	  o de ambos casos, o .... ? Si un usuario pertenece a multiples grupos, como funciona el menu?
	  Hay un grupo primario/default y ......
	  En otro caso, el menu utiliza lo que el servicio devuelve?

	- Seria util compilar un doc que incluya feedback provisto x los usuarios durante el soporte
	  Este feedback puede incluir aspectos visuales, usabilidad de la interfaz/app, funcionalidad, 
	  facilidad para su mantenimiento, etc., etc.

* TODO

	- La version automatica del DataForm parece no satisfacer nuestros requerimientos 
	  (los mensajes de error no son localizables, un textbox para un campo nrico. necesita un 0,
	   cuando se muestra una propiedad de navegacion aparece el tipo de dato, etc.)

	- Ventana de busqueda de menu

	- Menu de opciones

	TipoMenu(107): MENU (Padre)
	TipoMenu(203): MENU_FORM   (sub menu: e.g. Parametrizaciones)
	TipoMenu(200) && ('mnurpt' or '<reporte>'): REPORTE
	TipoMenu(200) && ('abm'): FORM_ABM
	TipoMenu(200) && !('abm' && !REPORTE): FORM

	2017-08-11..17

	Login: Sucursal x defecto                             [Done ]
	       Agregar un 'ojito' al text box Usuario         [Done ]
	       Debe aparecer apenas se ejecuta la application [Done ]
	Busqueda Menu                                         [Parcialmente implementado]
	Actualizar el JSon para el menu de opciones (agregue abm, operatoria, esta en toolbar, esta en menu) [Done]

2017-08-24
    * Approx. 930 menu items

	* Se agrego un combo box en ventana login que muestra las sucursales
	  Si el usuario en cuestion posee una sola sucursal, se cierra la ventana login y se procede a
	  preparar el menu correspondiente
	  Si posee mas de una sucursal, el usuario debera seleccionar una de ellas.
	  La sucursal x defecto debe aparecer primera en la lista.

    * Hay menu de opciones con un texto muy largo (> 60) 
	  E.g. PLA y FT - Operaciones realizadas por residentes en pa�ses de baja o nula tributaci�n (85 chars)
	       Prevenci�n L.A. y L.T - Resultado Matriz de Riesgo (Reducido) (62 chars)

    * Hay 21 opciones de menu con orden_menu = NULL (e.g. Venta Mostrador)