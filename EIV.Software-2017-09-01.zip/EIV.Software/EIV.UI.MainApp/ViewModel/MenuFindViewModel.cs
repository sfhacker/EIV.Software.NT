﻿
namespace EIV.UI.MainApp.ViewModel
{
    using EIV.Plugin.Helpers;
    public sealed class MenuFindViewModel
    {
        private RelayCommand testCommand = null;
    }
}