﻿
namespace EIV.UI.MainApp
{
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Windows;
    using System.Windows.Data;

    using Telerik.Windows.Controls;

    /// <summary>
    /// Interaction logic for TestDataForm.xaml
    /// </summary>
    public partial class TestDataForm : RadWindow
    {
        private Plugin.DataFormViewModel myViewModel = null;

        private object tempEntity = null;
        private IList<object> itemsToDelete = null;

        //private string title = null;
        //private object currentItem = null;

        public TestDataForm()
        {
            InitializeComponent();

            // It should take the Theme from its parent!
            this.Style = new Style(GetType(), this.FindResource(typeof(Telerik.Windows.Controls.RadWindow)) as Style);
        }

        private void RadWindow_Loaded(object sender, RoutedEventArgs e)
        {
            // var here now
            this.itemsToDelete = new List<object>();
        }

        private void popUpDataForm_Loaded(object sender, RoutedEventArgs e)
        {
            IList<object> testList = new List<object>();

            this.myViewModel = this.DataContext as Plugin.DataFormViewModel;

            //this.popUpDataForm.CurrentItem = this.myViewModel.CurrentItem;

            testList.Add(this.myViewModel.CurrentItem);

            // it requires this line in order to show some of the buttons (e.g. Add, Delete)
            this.popUpDataForm.ItemsSource = new ObservableCollection<object>(testList);

            // This is optional
            // this.popUpDataForm.CurrentItem = this.myViewModel.CurrentItem;

            this.popUpDataForm.Visibility = Visibility.Visible;
        }

        // Esto no deberia estar aqui!
        private void popUpDataForm_AutoGeneratingField(object sender, Telerik.Windows.Controls.Data.DataForm.AutoGeneratingFieldEventArgs e)
        {
            if (e.PropertyName == "Provincia")
            {
                // Funca OK
                e.DataField.DataMemberBinding = new Binding("Provincia.Nombre");
            }
            if (e.PropertyName == "Pais")
            {
                // Funca OK
                e.DataField.DataMemberBinding = new Binding("Pais.Descripcion");
            }
        }

        private void popUpDataForm_EditEnded(object sender, Telerik.Windows.Controls.Data.DataForm.EditEndedEventArgs e)
        {
            var entity = this.popUpDataForm.CurrentItem as object;
            if (entity != null)
            {
                if (tempEntity != null)
                {
                    if (entity.Equals(tempEntity))
                    {
                        // in the Loaded event
                        if (this.myViewModel != null)
                        {
                            this.myViewModel.Insert(entity);
                        }

                        //if (this.genericTemplate != null)
                        //{
                        //    // TODO:
                        //    IODataResponse resp = this.genericTemplate.Insert(entity);
                        //    if (resp != null)
                        //    {
                        //        string respMessage = string.Format("{0}: {1}\r\n\r\n{2}", resp.StatusCode, resp.Message, resp.Error);

                        //        int errorValue = (int) MessageBoxImage.Information;
                        //        if (resp.StatusCode > 299 || resp.StatusCode < 200)
                        //        {
                        //            errorValue = (int) MessageBoxImage.Error;
                        //        }
                        //        MessageBox.Show(respMessage, "Nuevo Registro", MessageBoxButton.OK, (MessageBoxImage) errorValue);
                        //    }
                        //}

                        string rst = null;
                        if (string.IsNullOrEmpty(this.myViewModel.ErrorMessage))
                        {
                            rst = string.Format("{0}: {1}", this.myViewModel.StatusCode, this.myViewModel.StatusMessage);
                        } else
                        {
                            rst = string.Format("{0}: {1}\r\n{2}", this.myViewModel.StatusCode, this.myViewModel.StatusMessage, this.myViewModel.ErrorMessage);
                        }

                        MessageBox.Show(rst, "Nuevo Registro", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    tempEntity = null;

                    return;
                }


                MessageBox.Show("Se procedera a guardar los cambios", "Guardar cambios");

                if (this.myViewModel != null)
                {
                    // TODO:
                    this.myViewModel.Update(entity);

                    string rst = null;
                    if (string.IsNullOrEmpty(this.myViewModel.ErrorMessage))
                    {
                        rst = string.Format("{0}: {1}", this.myViewModel.StatusCode, this.myViewModel.StatusMessage);
                    }
                    else
                    {
                        rst = string.Format("{0}: {1}\r\n{2}", this.myViewModel.StatusCode, this.myViewModel.StatusMessage, this.myViewModel.ErrorMessage);
                    }

                    MessageBox.Show(rst, "Actualizar Registro", MessageBoxButton.OK, MessageBoxImage.Information);
                }

                //if (this.genericTemplate != null)
                //{
                //    // Refactor
                //    IODataResponse resp = this.genericTemplate.Update(entity);
                //    if (resp != null)
                //    {
                //        string respMessage = string.Format("{0}: {1}\r\n\r\n{2}", resp.StatusCode, resp.Message, resp.Error);

                //        int errorValue = (int) MessageBoxImage.Information;
                //        if (resp.StatusCode > 299 || resp.StatusCode < 200)
                //        {
                //            errorValue = (int) MessageBoxImage.Error;
                //        }
                //        MessageBox.Show(respMessage, "Actualizar Registro", MessageBoxButton.OK, (MessageBoxImage) errorValue);
                //    }
                //}
            }
        }

        private void popUpDataForm_DeletedItem(object sender, Telerik.Windows.Controls.Data.DataForm.ItemDeletedEventArgs e)
        {
            var entity = e.DeletedItem;
            if (entity != null)
            {
                // TODO: Test this
                //this.itemsToDelete.Add(entity);

                if (this.myViewModel != null)
                {
                    // TODO:
                    this.myViewModel.Delete(entity);

                    string rst = null;
                    if (string.IsNullOrEmpty(this.myViewModel.ErrorMessage))
                    {
                        rst = string.Format("{0}: {1}", this.myViewModel.StatusCode, this.myViewModel.StatusMessage);
                    }
                    else
                    {
                        rst = string.Format("{0}: {1}\r\n{2}", this.myViewModel.StatusCode, this.myViewModel.StatusMessage, this.myViewModel.ErrorMessage);
                    }

                    MessageBox.Show(rst, "Eliminar Registro", MessageBoxButton.OK, MessageBoxImage.Information);

                    this.Close();
                }
            }
        }

        private void popUpDataForm_AddedNewItem(object sender, Telerik.Windows.Controls.Data.DataForm.AddedNewItemEventArgs e)
        {
            var entity = e.NewItem;
            if (entity != null)
            {
                tempEntity = entity;
                // this.itemsToDelete.Add(entity);
            }
        }
    }
}