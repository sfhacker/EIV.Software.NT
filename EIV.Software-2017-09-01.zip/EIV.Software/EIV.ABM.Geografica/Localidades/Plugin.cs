﻿/// <summary>
/// Only only one Plugin.cs but many ViewModels ????
/// 
/// Include IPluginGUI interface into ViewModels ???
/// </summary>
namespace EIV.ABM.Geografica
{
    using EIV.Plugin;
    public sealed class Plugin : IPluginGUI
    {
        private string myName = "mnufrmlocalidad"; // "Localidades Template";
        private string myDescription = "A Simple Text Editor. Very Simple!";

        private IPluginHost myHost = null;
        private System.Windows.FrameworkElement myMainInterface = null;  // new ctlMain();
        // private System.Windows.Controls.UserControl myMainInterface = null;  // new ctlMain();
        private ABMViewModelBase myViewModel = null;

        // oData Service Context
        private object myServiceContext = null;

        public Plugin()
        {
            //
            // TODO: Add constructor logic here
            //

            //this.myMainInterface = new LocalidadesUserControl();

            this.myViewModel = new LocalidadesViewModel();
        }

        // Optional
        // maybe this should go in the ViewModel rather than here
        public Plugin(object serviceContext)
        {
            this.myServiceContext = serviceContext;

            this.myViewModel = new LocalidadesViewModel(this.myServiceContext);
        }

        public string Description
        {
            get
            {
                return this.myDescription;
            }
        }

        public IPluginHost Host
        {
            get
            {
                return this.myHost;
            }

            set
            {
                this.myHost = value;
            }
        }

        public System.Windows.FrameworkElement MainInterface
        {
            get
            {
                return this.myMainInterface;
            }
        }

        public string Name
        {
            get
            {
                return this.myName;
            }
        }

        public ABMViewModelBase ViewModel
        {
            get
            {
                return this.myViewModel;
            }
        }

        public void Dispose()
        {
        }

        public void Initialize()
        {
        }

        public void SetDataServiceContext(object serviceContext)
        {
            this.myServiceContext = serviceContext;
        }
    }
}