﻿/// <summary>
/// http://techqa.info/programming/question/34512252/creating-abstract-viewmodels-wpf
/// </summary>
namespace EIV.ABM.Geografica
{
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;

    using EIV.Plugin.Helpers;
    using EIV.Plugin;

    using Telerik.Windows.Controls;

    public sealed class LocalidadesViewModel : ABMViewModelBase
    {
        // Lexico entries
        private const string LEXICO_LOCALIDADES_TITLE = "Localidades_Title";
        private const string LEXICO_LOCALIDADES_DF_TITLE = "Localidades_DF_Title";

        private string windowTitle = "Localidades";
        private string dataFormTitle = "Localidades Data Form 2017";

        private RelayCommand cancelCommand = null;
        private RelayCommand saveCommand = null;
        private RelayCommand addUserCommand = null;
        private RelayCommand deleteUserCommand = null;

        private IList<object> gridColumns = null;
        private ObservableCollection<object> gridContent = null;

        private DataFormViewModel myDataFormModel = null;

        private object myLexicoContext = null;

        // http://docs.telerik.com/devtools/wpf/controls/radgridview/columns/how-to/use-radcontextmenu-mvvm
        //private DelegateCommand ClearSortCommand { get; private set; }

        public LocalidadesViewModel()
        {
            this.cancelCommand = new RelayCommand(DoCancel);
            this.saveCommand = new RelayCommand(DoSave);
            this.addUserCommand = new RelayCommand(AddUser);
            this.deleteUserCommand = new RelayCommand(DeleteUser);

            // DataForm View Model
            this.myDataFormModel = new DataFormViewModel(this);

            // Testing 2017-08-08
            this.myDataFormModel.AutoGeneratingField += MyDataFormModel_AutoGeneratingField;

            this.myDataFormModel.Title = this.dataFormTitle;
            this.myDataFormModel.CurrentItem = null;

            this.gridColumns = this.GenerateColumnsLocal();

            // this line should be in the other constructor
            // it requires oData Service context
            this.gridContent = this.LoadEntities();
        }

        private void MyDataFormModel_AutoGeneratingField(object sender, EventArgs e)
        {
            // here
            var testOne = "Alas";
        }

        // oData Service Context here
        public LocalidadesViewModel(object serviceContext)
            : this()
        {

        }
        public override RelayCommand InsertCommand
        {
            get
            {
                return this.addUserCommand;
            }

            set
            {
                throw new NotImplementedException();
            }
        }

        public override RelayCommand CancelCommand
        {
            get
            {
                throw new NotImplementedException();
            }

            set
            {
                throw new NotImplementedException();
            }
        }

        public override RelayCommand DeleteCommand
        {
            get
            {
                throw new NotImplementedException();
            }

            set
            {
                throw new NotImplementedException();
            }
        }

        public override string Icon
        {
            get
            {
                throw new NotImplementedException();
            }

            set
            {
                throw new NotImplementedException();
            }
        }

        public override RelayCommand SaveCommand
        {
            get
            {
                return this.saveCommand;
            }

            set
            {
                throw new NotImplementedException();
            }
        }

        public override string Title
        {
            get
            {
                return this.windowTitle;
            }

            set
            {
                this.windowTitle = value;
            }
        }

        public override ObservableCollection<object> GridContent
        {
            get
            {
                return this.gridContent;
            }
        }

        public override IList<object> GridColumns
        {
            get
            {
                return this.gridColumns;
            }
        }

        public override DataFormViewModel DataFormModel
        {
            get
            {
                return this.myDataFormModel;
            }

            set
            {
            }
        }

        public override void SetLexicoContext(object lexicoContext)
        {
            base.SetLexicoContext(lexicoContext);

            this.myLexicoContext = lexicoContext;
        }
        public override void ApplyLexico()
        {
            EIV.Globalization.Localization myLocal = null;

            if (this.myLexicoContext == null)
            {
                return;
            }

            myLocal = this.myLexicoContext as EIV.Globalization.Localization;

            object winTitle = myLocal.GetLexicoEntryValue(LEXICO_LOCALIDADES_TITLE);
            if (winTitle != null)
            {
                this.windowTitle = winTitle.ToString();
            }

            this.ColumnsTranslate();
        }

        public override RelayCommand UpdateCommand
        {
            get
            {
                throw new NotImplementedException();
            }

            set
            {
                throw new NotImplementedException();
            }
        }

        private void DoCancel(object param)
        {
        }

        private void DoSave(object param)
        {
            // we should save here
            if (param != null)
            {
                if (this.gridContent != null)
                {
                    this.gridContent.Add(param);
                }
            }
        }

        private void AddUser(object parameter)
        {
            if (parameter != null)
            {
                if (this.gridContent != null)
                {
                    // it displays this item onto the grid
                    this.gridContent.Add(parameter);
                }
            }
        }

        private void DeleteUser(object parameter)
        {
        }

        private void ColumnsTranslate()
        {
            if (this.gridColumns == null)
            {
                return;
            }
            EIV.Globalization.Localization myLocal = null;

            if (this.myLexicoContext == null)
            {
                return;
            }

            myLocal = this.myLexicoContext as EIV.Globalization.Localization;
            foreach (GridViewDataColumn col in this.gridColumns)
            {
                object colText = myLocal.GetLexicoEntryValue(col.UniqueName);
                if (colText != null)
                {
                    col.Header = colText.ToString();
                }
            }
        }
        private ObservableCollection<object> GenerateColumnsLocal()
        {
            ObservableCollection<object> rst = new ObservableCollection<object>();

            // rst.Add(new GridViewDataColumn() { Header = "{Pais Id}", UniqueName = "localidad_paisId", DataMemberBinding = new System.Windows.Data.Binding("paisId") });
            // rst.Add(new GridViewDataColumn() { Header = "Provincia Id", UniqueName = "localidad_provinciaId", DataMemberBinding = new System.Windows.Data.Binding("provinciaId") });

            rst.Add(new GridViewDataColumn() { Header = "Id", UniqueName = "localidad_id", DataMemberBinding = new System.Windows.Data.Binding("Id") });
            rst.Add(new GridViewDataColumn() { Header = "Nombre", UniqueName = "localidad_nombre", DataMemberBinding = new System.Windows.Data.Binding("Nombre") });
            rst.Add(new GridViewDataColumn() { Header = "Cod. Postal", UniqueName = "localidad_cp", DataMemberBinding = new System.Windows.Data.Binding("CodPostal") });

            // ItemsSourceBinding = new System.Windows.Data.Binding("provinciaId")
            // ItemsSourceBinding = new System.Windows.Data.Binding("pais")
            // ItemsSourceBinding = new System.Windows.Data.Binding("paisId")
            // ItemsSourceBinding = new System.Windows.Data.Binding("AvailableProvincias")

            // OK
            //rst.Add(new GridViewComboBoxColumn() { Header = "Provincia", UniqueName = "localidad_provincia", DataMemberBinding = new System.Windows.Data.Binding("ProvinciaId") { Mode = System.Windows.Data.BindingMode.TwoWay }, ItemsSource = this.GetAllProvincias(), SelectedValueMemberPath = "Id", DisplayMemberPath = "Nombre" });

            // rst.Add(new GridViewComboBoxColumn() { Name = "cboPais", Header = "Pais", UniqueName = "localidad_pais", DataMemberBinding = new System.Windows.Data.Binding("paisId"), SelectedValueMemberPath = "id", DisplayMemberPath = "nombre" });
            // rst.Add(new GridViewCheckBoxColumn() { Header = "Read Only", UniqueName = "localidad_readonly", DataMemberBinding = new System.Windows.Data.Binding("ReadOnly") });
            // rst.Add(new GridViewHyperlinkColumn() { Header = "Wikipedia", UniqueName = "localidad_wiki", DataMemberBinding = new System.Windows.Data.Binding("Wikipedia") });
            // rst.Add(new GridViewImageColumn() { Header = "Bandera", UniqueName = "localidad_bandera", DataMemberBinding = new System.Windows.Data.Binding("Bandera") });

            return rst;
        }

        private ObservableCollection<object> LoadEntities()
        {
            IDictionary<string, object> filters = null;

            PaisLocal Argentina = new PaisLocal() { Id = 8, Nombre = "Argentina" };
            ProvinciaLocal SantaFe = new ProvinciaLocal() { Id = 1, Nombre = "Santa Fe" };

            var rst = new ObservableCollection<object>();
            LocalidadLocal Rosario = new LocalidadLocal() { Id = 123, Nombre = "Rosario", CodPostal = "2000", ProvinciaId = SantaFe.Id, Provincia = SantaFe };
            LocalidadLocal SantaFeCapital = new LocalidadLocal() { Id = 54, Nombre = "Santa Fe", CodPostal = "3000", ProvinciaId = SantaFe.Id, Provincia = SantaFe };

            rst.Add(Rosario);
            rst.Add(SantaFeCapital);

            return rst;
        }
    }

    public sealed class PaisLocal
    {
        public int Id { get; set; }

        public string Nombre { get; set; }
    }
    public sealed class ProvinciaLocal
    {
        public int Id { get; set; }

        public string Nombre { get; set; }

        public PaisLocal Pais { get; set; }
    }

    public sealed class LocalidadLocal
    {
        public int Id { get; set; }

        public string Nombre { get; set; }

        public string CodPostal { get; set; }

        public int ProvinciaId { get; set; }
        public ProvinciaLocal Provincia { get; set; }
    }
}