﻿
namespace EIV.Plugin
{
    public interface IPluginGUI : IPlugin
    {
        // PresentationFramework
        System.Windows.FrameworkElement MainInterface { get; }
        //  MainInterface { get; }

        ABMViewModelBase ViewModel { get; }

        // oData Service Context
        void SetDataServiceContext(object serviceContext);

        // In ABM base model (?)
        //void SetLexicoContext(object lexicoContext);
    }
}