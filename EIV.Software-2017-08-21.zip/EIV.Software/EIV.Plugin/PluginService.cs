﻿
namespace EIV.Plugin
{
    using System;
    using System.IO;
    using System.Reflection;

    public sealed class PluginService : IPluginHost
    {
        private const string PLUGIN_INTERFACE = "EIV.Plugin.IPluginGUI";

        private object[] myPlugInParameters = null;

        private AvailablePlugins colAvailablePlugins = null;

        private string myErrorMessage = null;

        public PluginService()
        {
            this.colAvailablePlugins = new AvailablePlugins();
        }

        // Parameters for all plugins
        // For example, oData Service Context
        public PluginService(object[] plugInParameters) : this()
        {
            this.myPlugInParameters = plugInParameters;
        }

        public AvailablePlugins AvailablePlugins
        {
            get { return this.colAvailablePlugins; }
            internal set { this.colAvailablePlugins = value; }
        }

        public string ErrorMessage
        {
            get
            {
                return this.myErrorMessage;
            }
        }
        public void Feedback(IPlugin plugin)
        {
            throw new NotImplementedException();
        }

        public void FindPlugins()
        {
            this.myErrorMessage = null;

            FindPlugins(AppDomain.CurrentDomain.BaseDirectory);
        }
        /// <summary>
        /// Searches the passed Path for Plugins
        /// </summary>
        /// <param name="Path">Directory to search for Plugins in</param>
        public void FindPlugins(string Path)
        {
            this.myErrorMessage = null;

            if (!Directory.Exists(Path))
            {
                this.myErrorMessage = string.Format("Invalid Path: {0}", Path);

                return;
            }
            //First empty the collection, we're reloading them all
            colAvailablePlugins.Clear();

            //Go through all the files in the plugin directory
            foreach (string fileOn in Directory.GetFiles(Path))
            {
                FileInfo file = new FileInfo(fileOn);

                //Preliminary check, must be .dll
                if (file.Extension.Equals(".dll"))
                {
                    //Add the 'plugin'
                    this.AddPlugin(fileOn);

                    //if (this.AvailablePlugins.Count > 0)
                    //{
                    //    break;
                    //}
                }
            }
        }

        /// <summary>
        /// Unloads and Closes all AvailablePlugins
        /// </summary>
        public void ClosePlugins()
        {
            foreach (AvailablePlugin pluginOn in colAvailablePlugins)
            {
                //Close all plugin instances
                //We call the plugins Dispose sub first incase it has to do 
                //Its own cleanup stuff
                pluginOn.Instance.Dispose();

                //After we give the plugin a chance to tidy up, get rid of it
                pluginOn.Instance = null;
            }

            //Finally, clear our collection of available plugins
            colAvailablePlugins.Clear();
        }

        private void AddPlugin(string FileName)
        {
            Type[] pluginTypes = null;

            //Create a new assembly from the plugin file we're adding..
            Assembly pluginAssembly = Assembly.LoadFrom(FileName);

            //Next we'll loop through all the Types found in the assembly
            // .GetTypes(): Error: No se puede cargar uno o mas tipos requeridos .......
            try
            {
                pluginTypes = pluginAssembly.GetTypes();
            }
            catch (ReflectionTypeLoadException ex)
            {
                this.myErrorMessage = ex.Message;

                return;
            }
            catch (Exception ex)
            {
                this.myErrorMessage = ex.Message;

                return;
            }

            if (pluginTypes == null)
            {
                return;
            }
            foreach (Type pluginType in pluginTypes)
            {
                if (pluginType.IsPublic) //Only look at public types
                {
                    if (!pluginType.IsAbstract)  //Only look at non-abstract types
                    {
                        //Gets a type object of the interface we need the plugins to match
                        Type typeInterface = pluginType.GetInterface(PLUGIN_INTERFACE, true);

                        //Make sure the interface we want to use actually exists
                        if (typeInterface != null)
                        {
                            //Create a new available plugin since the type implements the IPlugin interface
                            AvailablePlugin newPlugin = new AvailablePlugin();

                            //Set the filename where we found it
                            newPlugin.AssemblyPath = FileName;

                            //Create a new instance and store the instance in the collection for later use
                            //We could change this later on to not load an instance.. we have 2 options
                            //1- Make one instance, and use it whenever we need it.. it's always there
                            //2- Don't make an instance, and instead make an instance whenever we use it, then close it
                            //For now we'll just make an instance of all the plugins

                            // This is all-or-nothing approach
                            // Maybe we should use a property rather than an params in the constructor
                            if (this.myPlugInParameters == null)
                            {
                                newPlugin.Instance = (IPlugin) Activator.CreateInstance(pluginAssembly.GetType(pluginType.ToString()));
                            }
                            else
                            {
                                string alas = pluginType.ToString();
                                bool rst = this.HasParameters(pluginType);

                                newPlugin.Instance = (IPlugin) Activator.CreateInstance(pluginAssembly.GetType(pluginType.ToString()), args: this.myPlugInParameters);
                            }

                            //Set the Plugin's host to this class which inherited IPluginHost
                            newPlugin.Instance.Host = this;

                            //Call the initialization sub of the plugin
                            newPlugin.Instance.Initialize();

                            //Add the new plugin to our collection here
                            this.colAvailablePlugins.Add(newPlugin);

                            //cleanup a bit
                            newPlugin = null;
                        }

                        typeInterface = null; //Mr. Clean			
                    }
                }
            }

            pluginAssembly = null; //more cleanup
        }

        // Returns true if a public constructor has at least one parameter
        // we should check for the param type as well here
        private bool HasParameters(Type plugin)
        {
            if (plugin == null)
            {
                return false;
            }

            ConstructorInfo[] testConst = plugin.GetConstructors();
            if (testConst == null)
            {
                return false;
            }

            foreach (ConstructorInfo ctor in testConst)
            {
                ParameterInfo[] ctorParams = ctor.GetParameters();
                if (ctorParams != null)
                {
                    if (ctorParams.Length > 0)
                    {
                        return true;
                    }
                }
            }

            return false;
        }
    }
}