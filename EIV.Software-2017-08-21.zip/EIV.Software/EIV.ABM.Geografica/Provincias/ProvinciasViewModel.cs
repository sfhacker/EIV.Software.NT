﻿
namespace EIV.ABM.Geografica
{
    using EIV.Plugin;
    using EIV.Plugin.Helpers;

    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Windows;
    using Telerik.Windows.Controls;

    public sealed class ProvinciasViewModel : ABMViewModelBase, IPluginGUI
    {
        // Entity Set Name
        private const string ENTITY_SET_NAME = "Provincias";

        private string myName = "Provincias Template";
        private string windowTitle = "Provincias";
        private string dataFormTitle = "Provincias Data Form";

        private IPluginHost myHost = null;

        private RelayCommand cancelCommand = null;
        private RelayCommand saveCommand = null;
        private RelayCommand addProvinciaCommand = null;
        private RelayCommand updateProvinciaCommand = null;
        private RelayCommand deleteProvinciaCommand = null;

        private IList<object> gridColumns = null;
        private ObservableCollection<object> gridContent = null;

        private DataFormViewModel myDataFormModel = null;

        private object myLexicoContext = null;

        // oData Service Context
        private object myDataServiceContext = null;

        #region ABMViewModelBase Class Members
        public override string Title
        {
            get
            {
                return this.windowTitle;
            }

            set
            {
                
            }
        }

        public override string Icon
        {
            get
            {
                return null;
            }

            set
            {
            }
        }

        public override DataFormViewModel DataFormModel
        {
            get
            {
                return this.myDataFormModel;
            }

            set
            {
            }
        }

        public override ObservableCollection<object> GridContent
        {
            get
            {
                return this.gridContent;
            }
        }

        public override IList<object> GridColumns
        {
            get
            {
                return this.gridColumns;
            }
        }

        public override RelayCommand CancelCommand
        {
            get
            {
                return this.cancelCommand;
            }

            set
            {
            }
        }

        public override RelayCommand SaveCommand
        {
            get
            {
                return this.saveCommand;
            }

            set
            {
            }
        }

        public override RelayCommand InsertCommand
        {
            get
            {
                return this.addProvinciaCommand;
            }

            set
            {
            }
        }

        public override RelayCommand DeleteCommand
        {
            get
            {
                return this.deleteProvinciaCommand;
            }

            set
            {
            }
        }

        public FrameworkElement MainInterface
        {
            get
            {
                return null;
            }
        }

        public ABMViewModelBase ViewModel
        {
            get
            {
                return this;
            }
        }

        public IPluginHost Host
        {
            get
            {
                return this.myHost;
            }

            set
            {
                this.myHost = value;
            }
        }

        public string Name
        {
            get
            {
                return this.myName;
            }
        }

        public string Description
        {
            get
            {
                return null;
            }
        }

        public override RelayCommand UpdateCommand
        {
            get
            {
                return this.updateProvinciaCommand;
            }

            set
            {
            }
        }
        #endregion

        public ProvinciasViewModel()
        {
            this.cancelCommand = new RelayCommand(DoCancel);
            this.saveCommand = new RelayCommand(DoSave);
            this.addProvinciaCommand = new RelayCommand(AddProvincia);
            this.updateProvinciaCommand = new RelayCommand(UpdateProvincia);
            this.deleteProvinciaCommand = new RelayCommand(DeleteProvincia);

            // DataForm View Model
            this.myDataFormModel = new DataFormViewModel(this);

            this.myDataFormModel.Title = this.dataFormTitle;
            this.myDataFormModel.CurrentItem = null;

            this.gridColumns = this.GenerateColumns();
        }

        public ProvinciasViewModel(object serviceContext) : this()
        {
            this.myDataServiceContext = serviceContext;

            // This should be done when the grid is loading, not at this time!
            this.gridContent = this.LoadDataFromService();
        }

        #region IPluginGUI Interface members
        public void SetDataServiceContext(object serviceContext)
        {
            this.myDataServiceContext = serviceContext;
        }

        public void Initialize()
        {
            // Nothing here
        }

        public void Dispose()
        {
            // Nothing here
        }

        #endregion

        #region Commands
        private void DoCancel(object param)
        {
        }

        private void DoSave(object param)
        {
            // we should save here
            if (param != null)
            {
                if (this.gridContent != null)
                {
                    this.gridContent.Add(param);
                }
            }
        }

        private void AddProvincia(object parameter)
        {
            if (parameter != null)
            {
                if (this.gridContent != null)
                {
                    // it displays this item onto the grid
                    this.gridContent.Add(parameter);

                    // Should I persist this entity onto the DB at this time?
                    if (this.myDataServiceContext != null)
                    {
                        EIV.UI.ServiceContext.Service.UserControlService serviceContext = this.myDataServiceContext as EIV.UI.ServiceContext.Service.UserControlService;
                        var rst = serviceContext.Insert(ENTITY_SET_NAME, parameter);
                        if (rst != null)
                        {
                            this.myDataFormModel.StatusCode = rst.StatusCode;
                            this.myDataFormModel.StatusMessage = rst.Message;
                            this.myDataFormModel.ErrorMessage = rst.Error;
                        }

                        // TODO: El method de arribo NO (?) deberia persistir los datos, pero lo
                        // deberia decidir el usuario?
                        //var rst = serviceContext.SaveChanges();
                    }
                }
            }
        }

        private void UpdateProvincia(object parameter)
        {
            if (parameter == null)
            {
                return;
            }
            // Should I persist this entity onto the DB at this time?
            if (this.myDataServiceContext != null)
            {
                EIV.UI.ServiceContext.Service.UserControlService serviceContext = this.myDataServiceContext as EIV.UI.ServiceContext.Service.UserControlService;
                var rst = serviceContext.Update(parameter);
                if (rst != null)
                {
                    this.myDataFormModel.StatusCode = rst.StatusCode;
                    this.myDataFormModel.StatusMessage = rst.Message;
                    this.myDataFormModel.ErrorMessage = rst.Error;
                }

                // TODO: El method de arribo NO (?) deberia persistir los datos, pero lo
                // deberia decidir el usuario?
                //var rst = serviceContext.SaveChanges();
            }
        }

        private void DeleteProvincia(object parameter)
        {
            if (parameter == null)
            {
                return;
            }
            // Should I persist this entity onto the DB at this time?
            if (this.myDataServiceContext != null)
            {
                EIV.UI.ServiceContext.Service.UserControlService serviceContext = this.myDataServiceContext as EIV.UI.ServiceContext.Service.UserControlService;
                var rst = serviceContext.Delete(parameter);
                if (rst != null)
                {
                    this.myDataFormModel.StatusCode = rst.StatusCode;
                    this.myDataFormModel.StatusMessage = rst.Message;
                    this.myDataFormModel.ErrorMessage = rst.Error;
                }

                // TODO: El method de arribo NO (?) deberia persistir los datos, pero lo
                // deberia decidir el usuario?
                //var rst = serviceContext.SaveChanges();
            }
        }
        #endregion

        #region Columns & Data
        private ObservableCollection<object> GenerateColumns()
        {
            ObservableCollection<object> rst = new ObservableCollection<object>();

            rst.Add(new GridViewDataColumn() { Header = "Pais", UniqueName = "provincia_pais", DataMemberBinding = new System.Windows.Data.Binding("Pais") { ElementName = "Descripcion", Converter = new NameColConverter() } });
            rst.Add(new GridViewDataColumn() { Header = "Id", UniqueName = "provincia_id", DataMemberBinding = new System.Windows.Data.Binding("Id") });
            rst.Add(new GridViewDataColumn() { Header = "Descripcion", UniqueName = "provincia_desc", DataMemberBinding = new System.Windows.Data.Binding("Descripcion") });
            rst.Add(new GridViewDataColumn() { Header = "Desc. Red.", UniqueName = "provincia_desc_red", DataMemberBinding = new System.Windows.Data.Binding("DescripcionReducida") });

            return rst;
        }

        private ObservableCollection<object> LoadDataFromService()
        {
            ObservableCollection<object> rst = null;

            if (this.myDataServiceContext == null)
            {
                return null;
            }

            EIV.UI.ServiceContext.Service.UserControlService serviceContext = this.myDataServiceContext as EIV.UI.ServiceContext.Service.UserControlService;

            return serviceContext.LoadAllProvincias();
        }

        #endregion
    }

    // Es correcto esto aqui?
    public class NameColConverter : System.Windows.Data.IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            //manipulate your data here
            //return UserTemplate.Properties.Resources.Column_Name_Content;
            if (value != null)
            {
                if (value.GetType() == typeof(com.eiva.financiero.Pais))
                {
                    return ((com.eiva.financiero.Pais) value).Descripcion;
                }
            }
            return value;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}