﻿
namespace EIV.UI.MainApp.MenuService
{
    using Newtonsoft.Json;
    using Newtonsoft.Json.Linq;

    using System.Collections.Generic;
    using System.IO;
    using System.Linq;

    public sealed class MenuService
    {
        private MenuItem rootMenu = null;

        public MenuItem MainMenu
        {
            get
            {
                return this.rootMenu;
            }
        }

        public void LoadFullMenu()
        {
            JArray jsonMenu = null;

            // mutual_main_menu.json
            jsonMenu = this.LoadMenuFromJSon();
            if (jsonMenu == null)
            {
                return;
            }

            // Seems Ok
            // 973
            var menuList = JsonConvert.DeserializeObject<IList<JsonMenuItem>>(jsonMenu.ToString());

            rootMenu = new MenuItem() { Name = "Main", Text = "Menu Principal", IsEnabled = true };

            this.AppendSubItems(menuList, rootMenu);
        }

        public MenuItem PopulateUserMenu()
        {
            MenuItem rst = null;

            JArray jsonMenu = null;

            jsonMenu = this.LoadMenuFromJSon();
            if (jsonMenu == null)
            {
                return null;
            }

            var menuList = JsonConvert.DeserializeObject<IList<JsonMenuItem>>(jsonMenu.ToString());
            //var alas = menuList.GroupBy(m => m.MenuPadre).ToList();
            //foreach (var item in alas)
            //{
            //    var newAlas = item.GroupBy(p => p.MenuPadre).ToList();
            //}

            if (menuList == null)
            {
                return null;
            }

            rst = new MenuItem();

            // Testing ....
            IList<JsonMenuItem> terminalItem = new List<JsonMenuItem>();

            // Top Menu
            var topMenuItems = menuList.Where(m => m.MenuPadre.Equals("Main")).ToList();
            foreach (var menuItem in topMenuItems)
            {
                var menuMain = new MenuItem();
                menuMain.Name = menuItem.MenuNombre;
                menuMain.Text = menuItem.MenuLabel;

                var groupedByItems = menuList.Where(x => x.MenuPadre.Equals(menuItem.MenuNombre)).ToList();  // menuList.GroupBy(x => x.MenuPadre.Equals(menuItem.MenuNombre)).ToDictionary(g => g.Key, g => g.ToList());
                if (groupedByItems.Count > 0)
                {
                    AddChildren(menuMain, menuList);
                }

                rst.AddSubItem(menuMain);
            }

            return rst;
        }

        private void AddChildren(MenuItem topMenu, IList<JsonMenuItem> menuList)
        {
            if (menuList == null)
            {
                return;
            }
            if (topMenu == null)
            {
                return;
            }
            var groupedByItems = menuList.Where(x => x.MenuPadre.Equals(topMenu.Name)).ToList();
            if (groupedByItems.Count == 0)
            { return; }

            foreach (var child in groupedByItems)
            {
                var menuChild = new MenuItem();
                menuChild.Name = child.MenuNombre;
                menuChild.Text = child.MenuLabel;
                topMenu.AddSubItem(menuChild);

                AddChildren(menuChild, menuList);
            }
        }
        public SlideMenu.MenuButton GenerateUserMenu()
        {
            SlideMenu.MenuButton topMenu = null;

            JArray jsonMenu = null;

            jsonMenu = this.LoadMenuFromJSon();
            if (jsonMenu == null)
            {
                return null;
            }
            // Image="MenuImages/boss.png" Text="Sistema"
            //var one = new SlideMenu.MenuButton();
            //one.Image = new System.Windows.Media.Imaging.BitmapImage(new System.Uri("MenuImages/boss.png", System.UriKind.Relative));
            //one.Text = "Sistema (Dynamic)";

            return null;

            // 974
            // 994 (orden_menu IS NULL)
            // 928 (Guille)
            var menuList = JsonConvert.DeserializeObject<IList<JsonMenuItem>>(jsonMenu.ToString());
            //var alas = menuList.GroupBy(m => m.MenuPadre).ToList();
            //foreach (var item in alas)
            //{
            //    var newAlas = item.GroupBy(p => p.MenuPadre).ToList();
            //}

            // Testing ....
            IList<JsonMenuItem> terminalItem = new List<JsonMenuItem>();

            // Top Menu
            var groupedByItems = menuList.GroupBy(x => x.MenuPadre).ToDictionary(g => g.Key, g => g.ToList());
            foreach (var one in groupedByItems)
            {
                var menuItem = new MenuItem();
                menuItem.Name = one.Key;
                foreach (var two in one.Value)
                {
                    var subItem = new MenuItem();
                    subItem.Name = two.MenuNombre;
                    subItem.ParentMenu = menuItem;
                }
            }

            // all children (may not be terminal)
            var noIdea = groupedByItems.Where(g => g.Key.Equals("subCaja")).ToList();

            int countAlas = noIdea.Count;

            //foreach (var item in noIdea)
            //{
            //    // item.key = 'subCaja'
            //    // item.Value[0].MenuNombre = 'mnuform .....'
            //    foreach (var child in item.Value)
            //    {
            //        // child.MenuNombre = 'mnufrmCaja'
            //        // child.MenuNombre = 'mnufrmCierreCaja'
            //        // child.MenuNombre = 'subCajaPrm'
            //        // var testWanda = menuList.Where(q => q.MenuPadre.Equals(item.Key) && q.MenuNombre.Equals(child.MenuNombre)).ToList();
            //        //var testWanda = menuList.Where(q => q.MenuPadre.Equals(child.MenuNombre) && q.MenuNombre.Equals(child.MenuNombre)).ToList();
            //        var testWanda = menuList.Where(m => m.MenuPadre.Equals(child.MenuNombre)).ToList();
            //    }

            //}

            int testCount;

                                 // Top Menu
            foreach (var item in groupedByItems)
            {
                terminalItem = this.GetTerminalNodes(item.Value, menuList);

                if (item.Key.Equals("subSeguridad"))
                {
                    testCount = terminalItem.Count;
                }

                if (item.Key.Equals("subPersonas") || item.Key.Equals("subPersonasRep") || item.Key.Equals("subPersonasCli") || item.Key.Equals("subPersonasPrm"))
                {
                    testCount = terminalItem.Count;
                }

                //foreach (var child in item.Value)
                //{
                //    // child.MenuNombre = 'mnufrmCaja'
                //    // child.MenuNombre = 'mnufrmCierreCaja'
                //    // child.MenuNombre = 'subCajaPrm'
                //    // var testWanda = menuList.Where(q => q.MenuPadre.Equals(item.Key) && q.MenuNombre.Equals(child.MenuNombre)).ToList();
                //    //var testWanda = menuList.Where(q => q.MenuPadre.Equals(child.MenuNombre) && q.MenuNombre.Equals(child.MenuNombre)).ToList();
                //    var testWanda = menuList.Where(m => m.MenuPadre.Equals(child.MenuNombre)).ToList();
                //    if (testWanda.Count == 0)
                //    {
                //        terminalItem.Add(child);
                //    }
                //}
            }
            //

            testCount = terminalItem.Count;

            topMenu = new SlideMenu.MenuButton() { Name = "Main", Text = "Menu Principal", IsEnabled = true };

            this.AppendSubItemsBis(menuList, topMenu);

            var alas = topMenu.Children.Where(m => m.Children.Count > 0).ToList();

            return topMenu;
        }

        private IList<JsonMenuItem> GetTerminalNodes(IList<JsonMenuItem> topMenu, IList<JsonMenuItem> fullMenu)
        {
            IList<JsonMenuItem> rst = new List<JsonMenuItem>();

            foreach (var child in topMenu)
            {
                // child.MenuNombre = 'mnufrmCaja'
                // child.MenuNombre = 'mnufrmCierreCaja'
                // child.MenuNombre = 'subCajaPrm'
                // var testWanda = menuList.Where(q => q.MenuPadre.Equals(item.Key) && q.MenuNombre.Equals(child.MenuNombre)).ToList();
                //var testWanda = menuList.Where(q => q.MenuPadre.Equals(child.MenuNombre) && q.MenuNombre.Equals(child.MenuNombre)).ToList();
                var testWanda = fullMenu.Where(m => m.MenuPadre.Equals(child.MenuNombre)).ToList();
                if (testWanda.Count == 0)
                {
                    rst.Add(child);
                }
            }

            return rst;
        }

        private JArray LoadMenuFromJSon()
        {
            JArray jsonMenu = null;

            // mutual_main_menu.json
            using (System.IO.StreamReader file = File.OpenText(@"..\..\MenuData\new_mutual_main_menu.json"))
            using (JsonTextReader reader = new JsonTextReader(file))
            {
                jsonMenu = (JArray) JToken.ReadFrom(reader);
            }

            return jsonMenu;
        }

        #region MenuItems
        private void AppendSubItems(IList<JsonMenuItem> mainMenu, MenuItem topMenu)
        {
            foreach (JsonMenuItem item in mainMenu)
            {
                if (item.MenuPadre.Equals("Main"))
                {
                    MenuItem newMenu = new MenuItem() { Name = item.MenuNombre, Text = item.MenuLabel, ParentMenu = rootMenu, IsEnabled = true };
                    topMenu.AddSubItem(newMenu);
                }
            }

            foreach (MenuItem item in topMenu.SubItems)
            {
                var subItems = mainMenu.Where(x => x.MenuPadre.Equals(item.Name)).ToList();
                foreach (JsonMenuItem subItem in subItems)
                {
                    MenuItem subMenu = new MenuItem() { Name = subItem.MenuNombre, Text = subItem.MenuLabel, ParentMenu = item, IsEnabled = true };
                    //subMenu.Command = new DelegateCommand(OnMenuClickCommandExecuted);

                    item.AddSubItem(subMenu);
                }

                this.AppendChildren(mainMenu, item);
            }
        }

        // Falta ('Alta de Clientes') en Personas -> Reportes -> Cliente -> Alta de Clientes (a report)
        private void AppendChildren(IList<JsonMenuItem> mainMenu, MenuItem topMenu)
        {
            foreach (MenuItem item in topMenu.SubItems)
            {
                var subItems = mainMenu.Where(x => x.MenuPadre.Equals(item.Name)).ToList();
                foreach (JsonMenuItem subItem in subItems)
                {
                    MenuItem subMenu = new MenuItem() { Name = subItem.MenuNombre, Text = subItem.MenuLabel, ParentMenu = item, IsEnabled = true };
                    //subMenu.Command = new DelegateCommand(OnMenuClickCommandExecuted);

                    item.AddSubItem(subMenu);
                }
            }
        }
        #endregion

        #region MenuItems Bis
        private void AppendSubItemsBis(IList<JsonMenuItem> mainMenu, SlideMenu.MenuButton topMenu)
        {
            string menuCation = null;
            var image = new System.Windows.Media.Imaging.BitmapImage(new System.Uri("pack://application:,,,/EIV.UI.MainApp;component/Images/Icon.ico", System.UriKind.RelativeOrAbsolute));

            foreach (JsonMenuItem item in mainMenu)
            {
                if (item.MenuPadre.Equals("Main"))
                {
                    menuCation = (item.MenuLabel.Length < 25) ? item.MenuLabel : item.MenuLabel.Substring(0, 25);
                    SlideMenu.MenuButton newMenu = new SlideMenu.MenuButton() { Name = item.MenuNombre, Text = menuCation, IsEnabled = true, Tag = item.MenuNombre };
                    newMenu.Image = image;

                    topMenu.Children.Add(newMenu);
                }
            }

            foreach (SlideMenu.MenuButton item in topMenu.Children)
            {
                var subItems = mainMenu.Where(x => x.MenuPadre.Equals(item.Name)).ToList();
                foreach (JsonMenuItem subItem in subItems)
                {
                    // Información adicional: '<reporte>rptlistado_Apertura_Cuentas' is not a valid value for property 'Name'.
                    // Name = subItem.MenuNombre,
                    // &ltreporte&gt (Guille - Reemplazar '<' & '>')
                    menuCation = (subItem.MenuLabel.Length < 25) ? subItem.MenuLabel : subItem.MenuLabel.Substring(0, 25);
                    SlideMenu.MenuButton subMenu = new SlideMenu.MenuButton() { Text = menuCation, IsEnabled = true, Tag = subItem.MenuNombre };
                    //subMenu.Command = new DelegateCommand(OnMenuClickCommandExecuted);

                    item.Children.Add(subMenu);
                }

                this.AppendChildrenBis(mainMenu, item);
            }
        }

        // Falta ('Alta de Clientes') en Personas -> Reportes -> Cliente -> Alta de Clientes (a report)
        private void AppendChildrenBis(IList<JsonMenuItem> mainMenu, SlideMenu.MenuButton topMenu)
        {
            string menuCation = null;
            var image = new System.Windows.Media.Imaging.BitmapImage(new System.Uri("pack://application:,,,/EIV.UI.MainApp;component/Images/reminder.png", System.UriKind.RelativeOrAbsolute));

            foreach (SlideMenu.MenuButton item in topMenu.Children)
            {
                var subItems = mainMenu.Where(x => x.MenuPadre.Equals(item.Tag)).ToList();
                foreach (JsonMenuItem subItem in subItems)
                {
                    // Name = subItem.MenuNombre,
                    menuCation = (subItem.MenuLabel.Length < 25) ? subItem.MenuLabel : subItem.MenuLabel.Substring(0, 25);
                    SlideMenu.MenuButton subMenu = new SlideMenu.MenuButton() { Text = menuCation, IsEnabled = true, Tag = subItem.MenuNombre };
                    subMenu.Image = image;

                    //subMenu.Command = new DelegateCommand(OnMenuClickCommandExecuted);

                    item.Children.Add(subMenu);
                }
            }
        }
        #endregion
    }

    internal sealed class JsonMenuItem
    {
        [JsonProperty(PropertyName = "nombre_menu_padre")]
        public string MenuPadre { get; set; }

        [JsonProperty(PropertyName = "tipo_menu")]
        public int MenuTipo { get; set; }

        [JsonProperty(PropertyName = "orden_menu")]
        public int MenuOrden { get; set; }

        [JsonProperty(PropertyName = "abm")]
        public int MenuABM { get; set; }

        [JsonProperty(PropertyName = "operatoria")]
        public int MenuOperatoria { get; set; }

        [JsonProperty(PropertyName = "esta_en_toolbar")]
        public int MenuEstaEnToolbar { get; set; }

        [JsonProperty(PropertyName = "esta_en_menu")]
        public int MenuEstaEnMenu { get; set; }

        [JsonProperty(PropertyName = "nombre_menu")]
        public string MenuNombre { get; set; }

        [JsonProperty(PropertyName = "etiqueta")]
        public string MenuLabel { get; set; }
    }
}