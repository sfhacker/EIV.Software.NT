﻿

namespace EIV.UI.MainApp
{
    using System.Collections.Generic;
    public sealed class Usuario
    {
        public Usuario()
        {
            this.Sucursales = null;
            this.UserMenu = null;
            this.IsAuthenticated = false;
        }

        public bool IsAuthenticated { get; internal set; }
        public string UserName { get; set; }

        public IList<string> Sucursales { get; set; }

        public MenuItem UserMenu { get; set; }
    }
}