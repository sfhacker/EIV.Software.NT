﻿
namespace EIV.UI.MainApp.ViewModel
{
    public sealed class LoginViewModel
    {
        private Usuario currentUser = null;

        public LoginViewModel()
        {
        }

        public Usuario CurrentUser
        {
            get
            {
                return this.currentUser;
            }
            internal set {
                this.currentUser = value;
            }

        }
    }
}