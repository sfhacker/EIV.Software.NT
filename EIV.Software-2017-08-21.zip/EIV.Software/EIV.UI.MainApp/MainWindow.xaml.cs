﻿/// <summary>
/// 
/// </summary>
namespace EIV.UI.MainApp
{
    using SlideMenu;
    using System.Configuration;
    using System.Windows;
    using System.Windows.Input;

    using Telerik.Windows.Controls;
    using ServiceContext.Interface;
    using ServiceContext.Service;

    using System.Windows.Threading;
    using System;

    using View;

    using ViewModel;

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private const string SERVICE_URL   = "ServiceURL";
        private const string SERVER_NAME   = "ServerName";
        private const string ABM_FOLDER    = "ABM_Folder";
        private const string LANGUAGE_CODE = "CurrentUICulture";
        private const string THEME_NAME    = "CurrentTheme";
        private const string LEXICON_NAME  = "CurrentLexicon";

        private const string TERMINAL_NODE_ICON = "pack://application:,,,/EIV.UI.MainApp;component/Images/reminder.png";
        private const string MAIN_NODE_ICON = "pack://application:,,,/EIV.UI.MainApp;component/Images/Icon.ico";

        private IUserControlService formService = null;
        private EIV.Plugin.PluginService pluginService = null;

        private EIV.TelerikThemes.TelerikTheme myTheme = null;
        private EIV.Globalization.Localization myLocal = null;

        private string serviceURL = null;
        private string serverName = null;
        private string abmFolder = null;
        private string myLanguageCode = null;
        private string myThemeName = null;
        private string myLexiconName = null;

        public MainWindow()
        {
            InitializeComponent();
            IconSources.ChangeIconsSet(IconsSet.Modern);

            // App.config details
            this.serviceURL = this.ReadAppSetting(SERVICE_URL);
            this.serverName = this.ReadAppSetting(SERVER_NAME);
            this.abmFolder = this.ReadAppSetting(ABM_FOLDER);
            this.myLanguageCode = this.ReadAppSetting(LANGUAGE_CODE);
            this.myThemeName = this.ReadAppSetting(THEME_NAME);
            this.myLexiconName = this.ReadAppSetting(LEXICON_NAME);

            this.formService = new UserControlService();

            this.lblBranchName.Text = this.serverName;
            this.lblUserName.Text = this.GetFullUserName();
            this.SetDateTimeTimer();

            // Can connect later on
            bool rst = this.formService.Connect(this.serviceURL);

            // Testing passing params to Plugins constructor
            object[] argValues = new object[] { this.formService };
            pluginService = new EIV.Plugin.PluginService(argValues);

            // System.AppDomain.CurrentDomain.BaseDirectory + @"Plugins"
            // @"..\..\..\LocalidadesPlugin\bin\Debug"   [Ok]
            pluginService.FindPlugins(this.abmFolder);

            //Add each plugin to the treeview
            foreach (EIV.Plugin.AvailablePlugin pluginOn in pluginService.AvailablePlugins)
            {
                string newNode = pluginOn.Instance.Name;
                newNode = null;
            }

            this.lblStatus.Text = string.Format("Total ABMs: {0}", pluginService.AvailablePlugins.Count);

            // -------------------------- Theme -------------------------
            // Is this working fine?
            // It requires the specific Telerik Themes DLL files
            myTheme = new EIV.TelerikThemes.TelerikTheme();
            if (myTheme.Validate(this.myThemeName))   // this.ValidateThemeName(this.myThemeName)
            {
                myTheme.SetCurrentTheme(this.myThemeName);
            }
            
            System.Collections.ObjectModel.Collection<ResourceDictionary> dictNow = myTheme.GetThemeDictionary();

            // base.Resources
            this.ApplyTheme(this.Resources, dictNow);


            // --------  Language (before Lexico) --------------------
            myLocal = new EIV.Globalization.Localization();
            if (myLocal.ValidateCultureName(this.myLanguageCode))     // this.ValidateCultureName(this.myLanguageCode)
            {
                if (!string.IsNullOrEmpty(this.myLanguageCode))
                {
                    System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo(this.myLanguageCode);
                    System.Threading.Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo(this.myLanguageCode);
                }
            }

            // -------------------------- Lexico ------------------------------
            // is there any default?
            //myLocal.SetCurrentLexico(EIV.Globalization.Localization.LexicaEnum.Cooperativa);
            if (myLocal.ValidateLexiconName(this.myLexiconName))    // this.ValidateLexiconName(this.myLexiconName)
            {
                // TODO:
                // myLocal.SetCurrentLexico(EIV.Globalization.Localization.LexicaEnum.Cooperativa);
                myLocal.SetCurrentLexico(this.myLexiconName);
            }
        }

        private void ButtonBase_OnClick(object sender, RoutedEventArgs e)
        {
            Menu.Toggle();
        }

        private void Custom_OnClick(object sender, RoutedEventArgs e)
        {
            //CustomMenu.Toggle();
        }

        private void UIElement_OnMouseDown(object sender, MouseButtonEventArgs e)
        {
            MessageBox.Show("You Clicked Packing!");
        }

        private void DefaultClick(object sender, RoutedEventArgs e)
        {
            Menu.Theme = SideMenuTheme.Default;
        }

        private void PrimaryClick(object sender, RoutedEventArgs e)
        {
            Menu.Theme = SideMenuTheme.Primary;
        }

        private void SuccessClick(object sender, RoutedEventArgs e)
        {
            Menu.Theme = SideMenuTheme.Success;
        }

        private void WarningClick(object sender, RoutedEventArgs e)
        {
            Menu.Theme = SideMenuTheme.Warning;
        }

        private void DangerClick(object sender, RoutedEventArgs e)
        {
            Menu.Theme = SideMenuTheme.Danger;
        }

        private void CloseClick(object sender, RoutedEventArgs e)
        {
            Menu.Hide();
        }

        private void PaisesClick(object sender, RoutedEventArgs e)
        {
            //MessageBox.Show("You Clicked Paises!");
            //var winPaises = new PaisesView();
            //winPaises.ShowDialog();
        }

        private void ToggleClosingTypeClick(object sender, RoutedEventArgs e)
        {
            Menu.ClosingType = Menu.ClosingType == ClosingType.Auto
                ? ClosingType.Manual
                : ClosingType.Auto;
        }

        private SideMenu MapMenuToTheme(SideMenuTheme theme)
        {
            //this should not be necesray but colors are not changing correctly
            //when changing theme porperty... maybe its needed to implement INotifyPropertyChanged
            return new SideMenu
            {
                MenuWidth = Menu.MenuWidth,
                Theme = theme,
                Menu = Menu.Menu
            };
        }

        private string GetFullUserName()
        {
            string fullUserName = null;

            if (this.formService == null)
            {
                return null;
            }

            if (string.IsNullOrEmpty(this.formService.DomainName))
            {
                fullUserName = this.formService.UserName;
            } else
            {
                fullUserName = string.Format("{0}\\{1}", this.formService.DomainName, this.formService.UserName);
            }

            return fullUserName;
        }

        private void SetDateTimeTimer()
        {
            DispatcherTimer dispatcherTimer = new System.Windows.Threading.DispatcherTimer();

            dispatcherTimer.Tick += new EventHandler(dispatcherTimer_Tick);
            dispatcherTimer.Interval = new TimeSpan(0, 0, 1);
            dispatcherTimer.Start();
        }

        private void dispatcherTimer_Tick(object sender, EventArgs e)
        {
            // Updating the Label which displays the current second
            //  HH:mm tt
            this.lblDateTime.Text = DateTime.Now.ToString("G");

            // Forcing the CommandManager to raise the RequerySuggested event
            CommandManager.InvalidateRequerySuggested();
        }

        // This could go in EIV.Helpers
        // System.Configuration
        private string ReadAppSetting(string key)
        {
            if (string.IsNullOrEmpty(key))
            {
                return string.Empty;
            }
            try
            {
                var appSettings = ConfigurationManager.AppSettings;
                string result = appSettings[key];

                return result;
            }
            catch (ConfigurationErrorsException)
            {
                /* Console.WriteLine("Error reading app settings"); */
                //this.statusInfo.Text = "Invalid App.config file.";
            }

            return string.Empty;
        }

        private void mnuPais_MouseDown(object sender, MouseButtonEventArgs e)
        {
            // MessageBox.Show("Proximamente", "Pais", MessageBoxButton.OK, MessageBoxImage.Information);

            Plugin.AvailablePlugin selectedPlugin = this.pluginService.AvailablePlugins.Find("Paises Template");
            if (selectedPlugin == null)
            {
                MessageBox.Show("Recurso no encontrado.", "Pais", MessageBoxButton.OK, MessageBoxImage.Error);

                this.lblStatus.Text = "ABM::Pais: No encontrado";

                return;
            }

            this.ShowDialogWindow(selectedPlugin);
        }

        private void mnuProvincia_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Menu.Hide();

            // MessageBox.Show("Proximamente", "Provincia", MessageBoxButton.OK, MessageBoxImage.Information);

            Plugin.AvailablePlugin selectedPlugin = this.pluginService.AvailablePlugins.Find("Provincias Template");
            if (selectedPlugin == null)
            {
                MessageBox.Show("Recurso no encontrado.", "Provincia", MessageBoxButton.OK, MessageBoxImage.Error);

                this.lblStatus.Text = "ABM::Provincia: No encontrado";

                return;
            }

            this.ShowDialogWindow(selectedPlugin);
        }

        // Dependency: EIV.UI.UserControlBase
        private void mnuLocalidad_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Menu.Hide();

            // Este nombre debe ser univoco (por lo menos dentro del mismo assembly)
            Plugin.AvailablePlugin selectedPlugin = this.pluginService.AvailablePlugins.Find("Localidades Template");
            if (selectedPlugin == null)
            {
                MessageBox.Show("Recurso no encontrado.", "Localidad", MessageBoxButton.OK, MessageBoxImage.Error);

                this.lblStatus.Text = "ABM::Localidad: No encontrado";

                return;
            }

            this.ShowDialogWindow(selectedPlugin);
        }

        private void mnuTipoBarrios_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Menu.Hide();

            // Este nombre debe ser univoco (por lo menos dentro del mismo assembly)
            Plugin.AvailablePlugin selectedPlugin = this.pluginService.AvailablePlugins.Find("Tipo Barrios Template");
            if (selectedPlugin == null)
            {
                MessageBox.Show("Recurso no encontrado.", "Tipo Barrios", MessageBoxButton.OK, MessageBoxImage.Error);

                this.lblStatus.Text = "ABM::Tipo Barrios: No encontrado";

                return;
            }

            this.ShowDialogWindow(selectedPlugin);
        }

        private void ShowDialogWindow(Plugin.AvailablePlugin abmForm)
        {
            if (abmForm == null)
            {
                return;
            }

            RadWindow radWin = new TestRadWindow();             // new RadWindow();
            //RadWindow radWin = new TestRadWindow(myTheme);             // new RadWindow();
            radWin.Owner = this;
            radWin.Height = 300;
            radWin.Width = 400;
            radWin.IsRestricted = true;

            // Works fine!
            // StyleManager.SetTheme(radWin, new Office_BlueTheme());
            StyleManager.SetThemeFromParent(radWin, this);

            // Works fine but it does not apply to the RadWindow
            //this.ApplyTheme(radWin.Resources, myTheme.GetThemeDictionary());
            radWin.WindowStartupLocation = WindowStartupLocation.CenterOwner;

            //radWin.Content = ((IPluginGUI)selectedPlugin.Instance).MainInterface;
            Plugin.ABMViewModelBase viewModel = ((Plugin.IPluginGUI) abmForm.Instance).ViewModel;

            // Should i put this in the TestRadWindow
            viewModel.SetLexicoContext(this.myLocal);

            // TODO: test (2017-08-09)
            // But the send this param when the plugin is created (in PluginService.cs)
            ((Plugin.IPluginGUI) abmForm.Instance).SetDataServiceContext(this.formService);

            // TODO: To test!!!!
            radWin.DataContext = viewModel;

            //radWin.ApplyTemplate();
            radWin.ShowDialog();
        }

        private void mnuLogin_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Menu.Hide();

            RadWindow loginWin = new LoginView();
            loginWin.Owner = this;
            loginWin.Closed += LoginWin_Closed;

            loginWin.ResizeMode = ResizeMode.CanMinimize;
            loginWin.WindowStartupLocation = WindowStartupLocation.CenterOwner;

            loginWin.ShowDialog();
        }

        private void LoginWin_Closed(object sender, WindowClosedEventArgs e)
        {
            // throw new NotImplementedException();
            if (sender == null)
            {
                return;
            }
            LoginView loginWin = sender as LoginView;
            LoginViewModel loginModel = loginWin.DataContext as LoginViewModel;

            if (loginModel == null)
            {
                return;
            }

            if (loginModel.CurrentUser == null)
            {
                return;
            }
            if (!loginModel.CurrentUser.IsAuthenticated)
            {
                MessageBox.Show("See you around!");

                this.Close();
            }

            SlideMenu.MenuButton topMenu = new SlideMenu.MenuButton() { Name = "Main", Text = "Menu Principal", IsEnabled = true };

            string menuCaption = null;
            foreach (MenuItem item in loginModel.CurrentUser.UserMenu.SubItems)
            {
                menuCaption = (item.Text.Length < 25) ? item.Text : item.Text.Substring(0, 25);

                MenuButton menu = new MenuButton() { Name = item.Name, Text = menuCaption, IsEnabled = true, Tag = null };
                if (item.SubItems.Count > 0)
                {
                    this.AddChildren(item, menu);
                }
                if (menu.Children.Count == 0)
                {
                    // TERMINAL_NODE_ICON
                    menu.Image = new System.Windows.Media.Imaging.BitmapImage(new System.Uri(MAIN_NODE_ICON, System.UriKind.RelativeOrAbsolute));
                    menu.MouseDown += Menu_MouseDown;     // Command = new DelegateCommand(OnMenuClickCommandExecuted);
                } else
                {
                    menu.Image = new System.Windows.Media.Imaging.BitmapImage(new System.Uri(MAIN_NODE_ICON, System.UriKind.RelativeOrAbsolute));
                }
                topMenu.Children.Add(menu);
            }

            var alas = this.Menu.Menu;
            if (alas.Content != null)
            {
                System.Windows.Controls.StackPanel testOne = alas.Content as System.Windows.Controls.StackPanel;

                testOne.Children.Add(topMenu);
            }
        }

        private void Menu_MouseDown(object sender, MouseButtonEventArgs e)
        {
            // throw new NotImplementedException();
            if (sender != null)
            {
                MenuButton menu = sender as MenuButton;
                if (menu != null)
                {
                    string tagName = menu.Tag as string;
                    MessageBox.Show(tagName, "Tag");
                }
            }
        }

        private void AddChildren(MenuItem item, MenuButton topMenu)
        {
            string menuCaption = null;

            if (topMenu == null)
            {
                return;
            }
            foreach (var child in item.SubItems)
            {
                //var menuChild = new MenuButton();

                menuCaption = (child.Text.Length < 25) ? child.Text : child.Text.Substring(0, 25);

                MenuButton menu = new MenuButton() { Text = menuCaption, IsEnabled = true, Tag = child.Name };

                topMenu.Children.Add(menu);

                this.AddChildren(child, menu);
            }
            if (topMenu.Children.Count == 0)
            {
                topMenu.MouseDown += Menu_MouseDown;     // Command = new DelegateCommand(OnMenuClickCommandExecuted);
                // TERMINAL_NODE_ICON
                topMenu.Image = new System.Windows.Media.Imaging.BitmapImage(new System.Uri(TERMINAL_NODE_ICON, System.UriKind.RelativeOrAbsolute));
            }
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (Keyboard.Modifiers == ModifierKeys.Control && e.Key == Key.F)
            {
                RadWindow searchWin = new MenuFindView();
                searchWin.Owner = this;
                searchWin.Width = 350;
                searchWin.Height = 350;
                searchWin.WindowStartupLocation = WindowStartupLocation.CenterOwner;

                searchWin.ShowDialog();
            }
        }

        private void ApplyTheme(ResourceDictionary resDict, System.Collections.ObjectModel.Collection<ResourceDictionary> theme)
        {
            if (resDict == null)
            {
                return;
            }
            if (theme == null)
            {
                return;
            }

            System.Collections.ObjectModel.Collection<ResourceDictionary> mergedDicts = Application.Current.Resources.MergedDictionaries;

            // This may not be desirable!
            mergedDicts.Clear();
            foreach (ResourceDictionary rd in theme)
            {
                mergedDicts.Add(rd);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            e.Handled = true;

            LoginViewModel loginModel = new LoginViewModel();

            RadWindow loginWin = new LoginView();
            loginWin.Owner = this;
            loginWin.Closed += LoginWin_Closed;
            loginWin.DataContext = loginModel;

            loginWin.ShowDialog();

            //var alas = this.Menu.Menu;
            //if (alas.Content != null)
            //{
            //    System.Windows.Controls.StackPanel testOne = alas.Content as System.Windows.Controls.StackPanel;
            //    foreach (var item in testOne.Children.OfType<MenuButton>())
            //    {
            //        var testTwo = item.Text;
            //    }

            //    // Ok
            //    // testOne.Children.Add(this.GenerateUserMenu());
            //    MenuService.MenuService menuService = new MainApp.MenuService.MenuService();
            //    SlideMenu.MenuButton testAllMenu = menuService.GenerateUserMenu();

            //    var wanda = testOne.Children.OfType<MenuButton>().ToList();
            //    wanda.Clear();
            //    wanda.AddRange(testAllMenu.Children);

            //    foreach (MenuButton item in testAllMenu.Children)
            //    {
            //        testOne.Children.Add(item);
            //    }
            //      // testOne.Children.Add(this.GenerateUserMenu());            // testOne.Children.Add(testAllMenu);

            //}

        }

        private SlideMenu.MenuButton GenerateUserMenu()
        {
            // var wan1 = new System.Uri("pack://application:,,,/EIV.UI.MainApp;component/Images/reminder.png", System.UriKind.RelativeOrAbsolute);
            // var wan2 = new System.Uri("Images/reminder.png", System.UriKind.RelativeOrAbsolute);

            // Image="MenuImages/boss.png" Text="Sistema"
            var one = new SlideMenu.MenuButton();
            one.Image = new System.Windows.Media.Imaging.BitmapImage(new System.Uri("pack://application:,,,/EIV.UI.MainApp;component/Images/Icon.ico", System.UriKind.RelativeOrAbsolute));
            one.Text = "Sistema (Dynamic)";

            var two = new SlideMenu.MenuButton();
            two.Image = new System.Windows.Media.Imaging.BitmapImage(new System.Uri("pack://application:,,,/EIV.UI.MainApp;component/Images/reminder.png", System.UriKind.RelativeOrAbsolute));
            two.Text = "Boy (Dynamic)";
            two.MouseDown += new MouseButtonEventHandler(dynamicMenu_MouseDown);

            one.Children.Add(two);

            return one;
        }

        private void dynamicMenu_MouseDown(object sender, MouseButtonEventArgs e)
        {
            string formName = null;

            var alas = sender;
            if (sender != null)
            {
                MenuButton testBtn = sender as MenuButton;
                if (testBtn.Tag != null) { formName = testBtn.Tag as string; }

                MessageBox.Show(formName);
            }
        }

    }
}