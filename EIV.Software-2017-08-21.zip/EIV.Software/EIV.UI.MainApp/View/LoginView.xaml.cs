﻿
namespace EIV.UI.MainApp.View
{
    using System.Windows;
    using Telerik.Windows.Controls;
    using ViewModel;

    /// <summary>
    /// Lógica de interacción para LoginView.xaml
    /// </summary>
    public partial class LoginView : RadWindow
    {
        private UsuarioService userService = null;

        public LoginView()
        {
            InitializeComponent();

            // It should take the Theme from its parent!
            this.Style = new Style(GetType(), this.FindResource(typeof(Telerik.Windows.Controls.RadWindow)) as Style);

            this.txtUserName.Text = "";
            this.txtUserName.Password = "";
            this.txtUserName.MaxLength = 32;
            this.txtUserName.ShowPasswordButtonVisibility = ShowPasswordButtonVisibilityMode.Auto;
            this.txtUserName.WatermarkBehavior = WatermarkBehavior.HideOnTextEntered;

            this.txtPassword.Text = "";
            this.txtPassword.Password = "";
            this.txtPassword.MaxLength = 32; 
            this.txtPassword.ShowPasswordButtonVisibility = ShowPasswordButtonVisibilityMode.Never;
            this.txtPassword.WatermarkBehavior = WatermarkBehavior.HideOnTextEntered;

            this.cboSeguridad.SelectedIndex = 0;
            //this.cboSucursal.SelectedIndex = 0;
            this.cboSucursal.Items.Clear();

            this.userService = new UsuarioService();
        }

        private void btnLogin_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            string strUserName = this.txtUserName.Password;
            string strPassword = this.txtPassword.Password;
            string strSeguridad = null;

            if (string.IsNullOrEmpty(strUserName))
            {
                RadWindow.Alert("Nombre de Usuario invalido");

                return;
            }
            if (string.IsNullOrEmpty(strPassword))
            {
                RadWindow.Alert("Password invalido");

                return;
            }

            if (this.cboSeguridad.SelectedItem != null)
            {
                RadComboBoxItem cboItem = this.cboSeguridad.SelectedItem as RadComboBoxItem;
                strSeguridad = cboItem.Content as string;
            }

            string txtMsg = string.Format("{0};{1};{2}", strUserName, strPassword, strSeguridad);

            MessageBox.Show(txtMsg);

            var currentUser = this.userService.Authenticate(strUserName, strPassword);

            if (currentUser != null)
            {
                RadWindow.Alert("Login Ok!");

                this.SetSucursal(currentUser);

                LoginViewModel loginModel = this.DataContext as LoginViewModel;
                if (loginModel != null)
                {
                    loginModel.CurrentUser = currentUser;
                }

                this.Close();

                return;
            }

            RadWindow.Alert("You shall not pass");
        }

        private void cboSeguridad_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            int cboIndex = this.cboSeguridad.SelectedIndex;

            if (cboIndex > 0)
            {
                this.txtUserName.Password = "";
                this.txtUserName.IsEnabled = false;

                this.txtPassword.Password = "";
                this.txtPassword.IsEnabled = false;

                //this.stackSucursal.Visibility = Visibility.Visible;
                this.lblSucursal.Visibility = Visibility.Visible;
                this.cboSucursal.Visibility = Visibility.Visible;

                return;
            }

            this.txtUserName.IsEnabled = true;
            this.txtPassword.IsEnabled = true;

            //this.stackSucursal.Visibility = Visibility.Collapsed;

            //this.lblSucursal.Visibility = Visibility.Hidden;
            //this.cboSucursal.Visibility = Visibility.Hidden;
        }

        private void cboSucursal_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
        }

        private void SetSucursal(Usuario user)
        {
            if (user == null)
            {
                return;
            }

            if (user.Sucursales == null)
            {
                return;
            }
            if (user.Sucursales.Count == 0)
            {
                return;
            }
            this.cboSucursal.Items.Clear();
            foreach (string sucursal in user.Sucursales)
            {
                this.cboSucursal.Items.Add(sucursal);
            }

            this.cboSucursal.SelectedIndex = 0;
            if (this.cboSucursal.Items.Count > 1)
            {
                this.cboSucursal.IsEnabled = true;
            }
        }
    }
}