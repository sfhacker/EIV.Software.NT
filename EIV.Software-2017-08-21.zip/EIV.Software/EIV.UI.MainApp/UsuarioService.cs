﻿
using System.Collections.Generic;

namespace EIV.UI.MainApp
{
    public sealed class UsuarioService
    {
        private const string DEFAULT_USERNAME = "admin";
        private const string DEFAULT_PASSWORD = "qwerty";

        private const string GUEST_USERNAME = "guest";
        private const string GUEST_PASSWORD = "guest";

        private MenuService.MenuService menuService = null;
        public UsuarioService()
        {
            this.menuService = new MenuService.MenuService();
        }

        public Usuario Authenticate(string userName, string password)
        {
            Usuario rst = null;

            if (string.IsNullOrEmpty(userName))
            {
                return null;
            }
            if (string.IsNullOrEmpty(password))
            {
                return null;
            }

            if (userName.Equals(DEFAULT_USERNAME) && password.Equals(DEFAULT_PASSWORD))
            {

                rst = new Usuario() { UserName = userName };
                rst.Sucursales = this.GetSucursales(rst);
                rst.UserMenu = this.GetMenu(rst);
                rst.IsAuthenticated = true;

                return rst;
            }
            if (userName.Equals(GUEST_USERNAME) && password.Equals(GUEST_PASSWORD))
            {

                rst = new Usuario() { UserName = userName };
                rst.Sucursales = this.GetSucursales(rst);
                rst.UserMenu = this.GetMenu(rst);
                rst.IsAuthenticated = true;

                return rst;
            }

            return null;

        }

        private IList<string> GetSucursales(Usuario user)
        {
            IList<string> rst = null;

            if (user == null)
            {
                return null;
            }

            rst = new List<string>();
            if (user.UserName.Equals(DEFAULT_USERNAME))
            {
                rst.Add("Rosario");
            } else
            {
                rst.Add("Santa Fe");
                rst.Add("Soldini");
                rst.Add("Rosario");
            }

            return rst;
        }

        private MenuItem GetMenu(Usuario user)
        {
            MenuItem rst = null;

            if (this.menuService == null)
            {
                return null;
            }
            if (user == null)
            {
                return null;
            }

            // TODO:
            rst = this.menuService.PopulateUserMenu();  //  new MenuItem(); // this.menuService.GenerateUserMenu();

            return rst;
        }
    }
}